# Kit ChuyMinesitoo (Blender 5.2)

ChuyMinesitoo (el de la capucha de ajolote) extraído de `avatares.blend`, con rig nuevo y cara expresiva. El archivo original no se modificó.

## Qué trae `Kit_ChuyMinesitoo.blend`

| Escena | Contenido |
|---|---|
| **ChuyMinesitoo** | Chuy en estudio, con cámaras `Cam_Cuerpo`, `Cam_Tres_Cuartos` y `Cam_Cara`. Formato vertical 1080×1920 a 30 fps. |
| **Chuy_en_el_Pueblo** | Chuy en la plaza del Kit Pueblo. El pueblo está *vinculado* desde `../Kit_Pueblo/Kit_Pueblo.blend`, así que deja las dos carpetas juntas. |

La colección **`CH_ChuyMinesitoo`** trae el cuerpo, el gorrito de ajolote, las gomitas de la espalda, el rig `ChuyMinesitoo_Rig` y las piezas de la cara. Está en la misma escala que el Kit Pueblo (1 stud = 0.35 m; Chuy mide 1.77 m).

## Usarlo en una animación

1. Crea tu archivo de episodio.
2. Ve a **Archivo › Anexar**, entra a `Kit_ChuyMinesitoo.blend › Collection` y elige **`CH_ChuyMinesitoo`**.
3. Si también quieres el pueblo, anexa `SET_Pueblo` desde `Kit_Pueblo.blend`.

Las texturas vienen empacadas.

## El rig del cuerpo

| Control | Para qué |
|---|---|
| **Raiz** (círculo en el piso) | Mueve todo el personaje. |
| **Cadera** | Sube, baja o gira el cuerpo. Con piernas IK, al bajarla dobla las rodillas. |
| **Torso_Inf, Torso_Sup, Cabeza** | Rotación FK. |
| **Brazo_Sup, Brazo_Inf, Mano (.L/.R)** | Brazos FK. |
| **Pie_IK.L/R** (cajita bajo cada pie) | Mueve el pie y la pierna lo sigue. X es lado, Y es frente o atrás y Z es arriba. |
| **Rodilla.L/R** (circulito al frente) | Hacia dónde apunta la rodilla. |
| **Pierna_Sup, Pierna_Inf** | Piernas en FK (para sentarse, por ejemplo). |

Para pasar de IK a FK en las piernas, usa la propiedad **`IK_Piernas`** del hueso `Raiz` (1 = IK, 0 = FK). También está en el panel. `.L` es el lado izquierdo de Chuy.

## La cara

Por defecto la cara se ve igual que el avatar: ojos de puntito y sonrisita.

Todo se anima en modo Pose con los deslizadores del hueso **Cara** (de 0 a 1, se pueden mezclar):

- **Boca:** Sonrisa, Triste, Plana, Abierta, Risa, Mueca (dientes), Grito, Nervioso, Lengua, Gato (forma :3), Puchero.
- **Ojos:** Parpadeo_L, Parpadeo_R, Ojos_Felices (^ ^), Ojos_Tristes, Ojos_Enojados, Ojos_Entrecerrados, Ojos_Grandes (ojo blanco con contorno; el puntito se vuelve pupila), Brillo.
- **Ojos especiales:** Corazones, Estrellas, Espirales, Ojos_X.
- **Extras:** Cejas (el avatar no tiene; aparecen al subir este valor), Rubor, Pena (rayitas), Lagrimas, Llanto (chorros), Sudor, Venita (enojo), Lineas_Shock.

Huesos de la cara:

- **Mirada:** a dónde ve.
- **Ojo.L/R:** mover o escalar el ojo.
- **Pupila.L/R:** tamaño del puntito.
- **Ceja.L/R:** subir, bajar y girar.
- **Boca:** mover, girar (sonrisa chueca) y escalar.

## Panel "Kit Chuy"

En la vista 3D presiona **N** y abre la pestaña **Kit Chuy**, con Chuy seleccionado. Ahí hay:

- **21 expresiones:** Neutral, Feliz, Muy feliz, Tierno, Triste, Llorando, Enojado, Furioso, Sorprendido, Asustado, Nervioso, Sospechoso, Malvado, Enamorado, Emocionado, Mareado, Noqueado, Dormido, Avergonzado, Guiño y Pensativo.
- **8 poses de cuerpo:** Reposo, Saludar, Festejar, Pensar, Susto, Caminar A, Caminar B y Sentado.
- **"Insertar parpadeo"** y todos los deslizadores.

Con "Insertar clave al aplicar" marcada, cada botón deja claves en el cuadro actual.

Si el panel no aparece, tienes dos opciones:

- Activa **Preferencias › Guardar y cargar › Ejecutar automáticamente scripts de Python** y vuelve a abrir el archivo.
- O abre el **Editor de texto**, elige `kit_chuy_ui.py` y pulsa **Ejecutar script**.

La cara funciona igual sin el panel.

## Regenerar

```
blender --background --factory-startup --python scripts/build_chuy.py -- previews
```

Por defecto lee `C:\Users\dealb\Videos\Youtube\Chuy Mine\Claude\avatares.blend`. Para usar otra ruta, agrega `src=RUTA`. Las expresiones y poses están en `scripts/chuy_ui.py`. `previews/` tiene renders de todas las expresiones y poses.
