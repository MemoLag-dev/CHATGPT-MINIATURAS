"""Materiales procedurales de los escenarios (sacados de las referencias)."""
import bpy, math
from kit_lib import (new_mat, flat, lin, shade, node, M, mixc, sep, comb, smooth, coords,
                     night_fac, tidy, _sock, setv)

_cache = {}


def cached(fn):
    def w(name, *a, **k):
        if name in _cache:
            return _cache[name]
        m = fn(name, *a, **k)
        _cache[name] = m
        return m
    return w


def _bump(nt, b, height, strength=0.3, dist=0.02):
    bump = node(nt, "ShaderNodeBump", {"Strength": strength, "Distance": dist, "Height": height})
    nt.links.new(bump.outputs["Normal"], b.inputs["Normal"])


@cached
def siding(name, hexcol, pitch=0.2):
    """Tablas horizontales traslapadas (casas de madera)."""
    m, nt, b = new_mat(name, 0.7)
    u, v, w = sep(nt, coords(nt))
    t = M(nt, "FRACT", M(nt, "DIVIDE", v, pitch))
    groove = M(nt, "LESS_THAN", t, 0.045)
    col = mixc(nt, t, shade(hexcol, 0.84), lin(hexcol))
    col = mixc(nt, groove, col, shade(hexcol, 0.62))
    b.inputs["Base Color"].default_value = lin(hexcol)
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, t, 0.25, 0.01)
    m.diffuse_color = lin(hexcol)
    tidy(nt)
    return m


@cached
def brick(name, c1="#b4533c", c2="#c76a4f", mortar="#ece6dc", w=0.24, h=0.08, ms=0.014):
    m, nt, b = new_mat(name, 0.85)
    br = node(nt, "ShaderNodeTexBrick", {"Vector": coords(nt), "Color1": lin(c1), "Color2": lin(c2),
                                          "Mortar": lin(mortar), "Scale": 1.0, "Mortar Size": ms,
                                          "Mortar Smooth": 0.1, "Bias": 0.0, "Brick Width": w,
                                          "Row Height": h}, offset=0.5, offset_frequency=2)
    nt.links.new(br.outputs["Color"], b.inputs["Base Color"])
    _bump(nt, b, M(nt, "SUBTRACT", 1.0, br.outputs["Fac"]), 0.35, 0.01)
    m.diffuse_color = lin(c1)
    tidy(nt)
    return m


@cached
def cobble(name, base="#d4d7db", mortar="#9a9fa6", scale=1.6, var=0.07):
    """Empedrado tipo Voronoi como el de la plaza."""
    m, nt, b = new_mat(name, 0.85)
    vec = coords(nt)
    ve = node(nt, "ShaderNodeTexVoronoi", {"Vector": vec, "Scale": scale, "Randomness": 0.9},
              feature="DISTANCE_TO_EDGE")
    vf = node(nt, "ShaderNodeTexVoronoi", {"Vector": vec, "Scale": scale, "Randomness": 0.9}, feature="F1")
    d = ve.outputs["Distance"]
    edge = smooth(nt, 0.035, 0.07, d)
    rnd = sep(nt, vf.outputs["Color"])[0]
    stone = mixc(nt, rnd, shade(base, 1 - var), shade(base, 1 + var * 0.6))
    rim = smooth(nt, 0.07, 0.22, d)
    stone = mixc(nt, rim, mixc(nt, 0.5, stone, lin(mortar)), stone)
    col = mixc(nt, edge, lin(mortar), stone)
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, smooth(nt, 0.0, 0.25, d), 0.6, 0.05)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def grass(name, base="#4e8f3a"):
    m, nt, b = new_mat(name, 0.95)
    vec = coords(nt)
    n1 = node(nt, "ShaderNodeTexNoise", {"Vector": vec, "Scale": 90.0, "Detail": 3.0, "Roughness": 0.7})
    n2 = node(nt, "ShaderNodeTexNoise", {"Vector": vec, "Scale": 1.2, "Detail": 2.0})
    col = mixc(nt, smooth(nt, 0.35, 0.65, n1.outputs["Fac"]), shade(base, 0.72), shade(base, 1.18))
    col = mixc(nt, M(nt, "MULTIPLY", smooth(nt, 0.4, 0.7, n2.outputs["Fac"]), 0.35), col, lin("#6aa84a"))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, n1.outputs["Fac"], 0.5, 0.02)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def asphalt(name, base="#3d4552"):
    m, nt, b = new_mat(name, 0.9)
    vec = coords(nt)
    n1 = node(nt, "ShaderNodeTexNoise", {"Vector": vec, "Scale": 140.0, "Detail": 2.0})
    n2 = node(nt, "ShaderNodeTexNoise", {"Vector": vec, "Scale": 0.6, "Detail": 2.0})
    spk = smooth(nt, 0.62, 0.7, n1.outputs["Fac"])
    col = mixc(nt, n2.outputs["Fac"], shade(base, 0.9), shade(base, 1.1))
    col = mixc(nt, M(nt, "MULTIPLY", spk, 0.6), col, shade(base, 1.6))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, n1.outputs["Fac"], 0.25, 0.01)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def tiles(name, base="#c8cbd0", groove="#8d939b", size=1.2, gw=0.03, rough=0.8):
    m, nt, b = new_mat(name, rough)
    u, v, w = sep(nt, coords(nt))
    fu = M(nt, "PINGPONG", M(nt, "DIVIDE", u, size), 0.5)
    fv = M(nt, "PINGPONG", M(nt, "DIVIDE", v, size), 0.5)
    d = M(nt, "MINIMUM", fu, fv)
    line = M(nt, "LESS_THAN", d, gw / size)
    n = node(nt, "ShaderNodeTexNoise", {"Vector": coords(nt), "Scale": 3.0})
    col = mixc(nt, n.outputs["Fac"], shade(base, 0.95), shade(base, 1.04))
    col = mixc(nt, line, col, lin(groove))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, M(nt, "SUBTRACT", 1.0, line), 0.3, 0.01)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def planks(name, base="#d9b48a", width=0.16, axis=0, groove=0.035, grain=True, rough=0.6):
    """Tablones de madera (pisos, bancas, escritorios). axis 0=u, 1=v."""
    m, nt, b = new_mat(name, rough)
    u, v, w = sep(nt, coords(nt))
    a = u if axis == 0 else v
    o = v if axis == 0 else u
    t = M(nt, "DIVIDE", a, width)
    idx = M(nt, "FLOOR", t)
    f = M(nt, "PINGPONG", t, 0.5)
    seam = M(nt, "LESS_THAN", f, groove)
    # junta transversal escalonada
    off = M(nt, "FRACT", M(nt, "ADD", M(nt, "DIVIDE", o, 1.8), M(nt, "MULTIPLY", idx, 0.37)))
    cross = M(nt, "LESS_THAN", off, 0.012)
    seam = M(nt, "MAXIMUM", seam, cross)
    rnd = node(nt, "ShaderNodeTexNoise", {"Vector": comb(nt, idx, M(nt, "FLOOR", M(nt, "ADD", M(nt, "DIVIDE", o, 1.8), M(nt, "MULTIPLY", idx, 0.37))), 0.0), "Scale": 7.3})
    col = mixc(nt, rnd.outputs["Fac"], shade(base, 0.9), shade(base, 1.08))
    if grain:
        g = node(nt, "ShaderNodeTexWave", {"Vector": comb(nt, M(nt, "MULTIPLY", o, 0.2), a, 0.0), "Scale": 18.0,
                                           "Distortion": 4.0, "Detail": 2.0}, wave_type="BANDS")
        col = mixc(nt, M(nt, "MULTIPLY", g.outputs["Fac"], 0.18), col, shade(base, 0.75))
    col = mixc(nt, seam, col, shade(base, 0.6))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, M(nt, "SUBTRACT", 1.0, seam), 0.3, 0.01)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def roof(name, hexcol, pitch=0.22):
    m, nt, b = new_mat(name, 0.8)
    u, v, w = sep(nt, coords(nt))
    t = M(nt, "FRACT", M(nt, "DIVIDE", w, pitch))
    col = mixc(nt, t, shade(hexcol, 0.85), lin(hexcol))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, t, 0.3, 0.02)
    m.diffuse_color = lin(hexcol)
    tidy(nt)
    return m


@cached
def leaves(name, base="#4f9a3c"):
    """Copa de árbol 'voxel' con manchas de hojas."""
    m, nt, b = new_mat(name, 0.9)
    vec = coords(nt)
    v1 = node(nt, "ShaderNodeTexVoronoi", {"Vector": vec, "Scale": 3.5, "Randomness": 1.0}, feature="SMOOTH_F1")
    v2 = node(nt, "ShaderNodeTexVoronoi", {"Vector": vec, "Scale": 9.0, "Randomness": 1.0}, feature="F1")
    d1 = v1.outputs["Distance"]
    col = mixc(nt, smooth(nt, 0.15, 0.6, d1), shade(base, 1.22), shade(base, 0.72))
    col = mixc(nt, M(nt, "MULTIPLY", smooth(nt, 0.0, 0.5, v2.outputs["Distance"]), 0.35), col, shade(base, 0.6))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, d1, 0.5, 0.05)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def bark(name, base="#6e4a32"):
    m, nt, b = new_mat(name, 0.9)
    u, v, w = sep(nt, coords(nt))
    wv = node(nt, "ShaderNodeTexWave", {"Vector": comb(nt, u, M(nt, "MULTIPLY", v, 0.08), w), "Scale": 6.0,
                                        "Distortion": 6.0, "Detail": 3.0}, wave_type="BANDS")
    col = mixc(nt, wv.outputs["Fac"], shade(base, 0.75), shade(base, 1.1))
    nt.links.new(col, b.inputs["Base Color"])
    _bump(nt, b, wv.outputs["Fac"], 0.4, 0.02)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def stucco(name, base="#eef0f3"):
    """Muro liso pintado (alcaldía, interiores) con variación muy suave."""
    m, nt, b = new_mat(name, 0.75)
    n = node(nt, "ShaderNodeTexNoise", {"Vector": coords(nt), "Scale": 2.5, "Detail": 3.0})
    col = mixc(nt, n.outputs["Fac"], shade(base, 0.96), shade(base, 1.02))
    nt.links.new(col, b.inputs["Base Color"])
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def stripes(name, c1, c2, width=0.45, axis="X"):
    """Rayas de toldo en coordenadas de objeto."""
    m, nt, b = new_mat(name, 0.7)
    tc = node(nt, "ShaderNodeTexCoord")
    x, y, z = sep(nt, tc.outputs["Object"])
    a = {"X": x, "Y": y, "Z": z}[axis]
    s = M(nt, "LESS_THAN", M(nt, "FRACT", M(nt, "DIVIDE", a, width)), 0.5)
    nt.links.new(mixc(nt, s, lin(c2), lin(c1)), b.inputs["Base Color"])
    m.diffuse_color = lin(c1)
    tidy(nt)
    return m


@cached
def glass(name, base="#a9cdee", night="#ffd79a"):
    """Vidrio opaco de ventana; de noche se ilumina (propiedad de escena 'noche')."""
    m, nt, b = new_mat(name, 0.15)
    tc = node(nt, "ShaderNodeTexCoord")
    lw = node(nt, "ShaderNodeLayerWeight", {"Blend": 0.35})
    col = mixc(nt, lw.outputs["Facing"], lin(base), shade(base, 1.25))
    nf = night_fac(nt)
    col = mixc(nt, nf, col, lin(night))
    nt.links.new(col, b.inputs["Base Color"])
    b.inputs["Emission Color"].default_value = lin(night)
    nt.links.new(M(nt, "MULTIPLY", nf, 2.5), b.inputs["Emission Strength"])
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def lamp_bulb(name, base="#fff6e0", day=0.3, night_str=12.0):
    m, nt, b = new_mat(name, 0.4)
    b.inputs["Base Color"].default_value = lin(base)
    b.inputs["Emission Color"].default_value = lin(base)
    nt.links.new(M(nt, "ADD", day, M(nt, "MULTIPLY", night_fac(nt), night_str)), b.inputs["Emission Strength"])
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def chalkboard(name, base="#2f6b57"):
    m, nt, b = new_mat(name, 0.85)
    n = node(nt, "ShaderNodeTexNoise", {"Vector": coords(nt), "Scale": 1.4, "Detail": 4.0})
    col = mixc(nt, n.outputs["Fac"], shade(base, 0.85), shade(base, 1.2))
    nt.links.new(col, b.inputs["Base Color"])
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def cloud(name):
    """Nube esponjosa: blanca de día, gris azulada de noche."""
    m, nt, b = new_mat(name, 1.0)
    nf = night_fac(nt)
    nt.links.new(mixc(nt, nf, lin("#ffffff"), lin("#46557a")), b.inputs["Base Color"])
    b.inputs["Emission Color"].default_value = lin("#eef3fa")
    nt.links.new(M(nt, "MULTIPLY", M(nt, "SUBTRACT", 1.0, nf), 0.45), b.inputs["Emission Strength"])
    m.diffuse_color = (1, 1, 1, 1)
    tidy(nt)
    return m


@cached
def water(name, base="#8ec9ee"):
    m, nt, b = new_mat(name, 0.05)
    n = node(nt, "ShaderNodeTexNoise", {"Vector": coords(nt), "Scale": 4.0, "Detail": 3.0})
    nt.links.new(mixc(nt, n.outputs["Fac"], shade(base, 0.85), shade(base, 1.15)), b.inputs["Base Color"])
    _bump(nt, b, n.outputs["Fac"], 0.2, 0.05)
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


@cached
def stars_blanket(name, base="#22357a", star="#f5c84a"):
    """Cobija azul con estrellas y lunas (cuarto)."""
    m, nt, b = new_mat(name, 0.9)
    tc = node(nt, "ShaderNodeTexCoord")
    v = node(nt, "ShaderNodeTexVoronoi", {"Vector": tc.outputs["Object"], "Scale": 9.0, "Randomness": 0.8},
             feature="F1")
    dot = M(nt, "LESS_THAN", v.outputs["Distance"], 0.16)
    nt.links.new(mixc(nt, dot, lin(base), lin(star)), b.inputs["Base Color"])
    m.diffuse_color = lin(base)
    tidy(nt)
    return m


def P(name, hexcol, rough=0.6, metal=0.0, emit=0.0):
    """Pintura plana (atajo)."""
    if name in _cache:
        return _cache[name]
    m = flat(name, hexcol, rough, metal, emit)
    _cache[name] = m
    return m
