"""Personajes del Kit Pueblo: cuerpo de bloques (6 piezas), rig y cara expresiva por controles."""
import bpy, bmesh, math, os
from mathutils import Vector, Matrix, Euler
from kit_lib import (MB, lin, shade, coll, new_mat, flat, node, M, mixc, sep, comb, smooth, tidy,
                     setv, _sock)
import kit_textures as KT
import kit_ui

# ------------------------------------------------------------------ medidas (metros)
TORSO_S = (0.70, 0.35, 0.70)
LIMB_S = (0.35, 0.35, 0.70)
TORSO_Z = 1.05
HEAD_R, HEAD_H, HEAD_RB = 0.225, 0.44, 0.1
HEAD_Z = 1.40 + HEAD_H / 2 + 0.004
FACE_Y = -(HEAD_R + 0.004)          # plano donde nacen las piezas de la cara
BONE_Y = -(HEAD_R + 0.03)           # controles de la cara (un poco al frente)
FACE_ROT = Matrix.Rotation(math.pi / 2, 4, "X")   # X local = X, Y local = Z (arriba), Z local = -Y (al frente)

# capas (separación sobre la cabeza para que no se encimen)
OFF = {"rubor": 0.0008, "ojo": 0.0015, "pupila": 0.0025, "parpado": 0.0036, "ceja": 0.0048,
       "boca": 0.0015, "lengua": 0.0022, "dientes": 0.0029, "gota": 0.0055}

KIT_DIR = None   # se fija desde build_kit


# ------------------------------------------------------------------ utilidades de malla
def mesh_from_bm(bm, name):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    return me


def body_box(name, size, regions, bevel=0.03):
    bm = bmesh.new()
    verts = bmesh.ops.create_cube(bm, size=1.0)["verts"]
    bmesh.ops.scale(bm, vec=size, verts=verts)
    bmesh.ops.bevel(bm, geom=bm.edges[:], offset=bevel, segments=3, affect="EDGES", profile=0.5,
                    clamp_overlap=True)
    uv = bm.loops.layers.uv.new("UVMap")
    hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        key = ("L" if n.x > 0 else "R") if ax == 0 else (("B" if n.y > 0 else "F") if ax == 1 else ("U" if n.z > 0 else "D"))
        rx, ry, rw, rh = regions[key]
        for l in f.loops:
            x, y, z = l.vert.co
            if key == "F":
                u, v = (x + hx) / (2 * hx), (hz - z) / (2 * hz)
            elif key == "B":
                u, v = (hx - x) / (2 * hx), (hz - z) / (2 * hz)
            elif key == "R":
                u, v = (hy - y) / (2 * hy), (hz - z) / (2 * hz)
            elif key == "L":
                u, v = (y + hy) / (2 * hy), (hz - z) / (2 * hz)
            elif key == "U":
                u, v = (x + hx) / (2 * hx), (hy - y) / (2 * hy)
            else:
                u, v = (x + hx) / (2 * hx), (y + hy) / (2 * hy)
            u, v = min(max(u, 0.0), 1.0), min(max(v, 0.0), 1.0)
            l[uv].uv = ((rx + u * rw) / 585.0, 1.0 - (ry + v * rh) / 559.0)
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def add_weighted_normals(ob):
    m = ob.modifiers.new("Normales", "WEIGHTED_NORMAL")
    m.mode = "FACE_AREA"
    m.weight = 100
    m.keep_sharp = True


def revolve(bm, prof, seg, center=(0, 0, 0)):
    """Gira un perfil (r, z) alrededor de Z. Los puntos con r=0 se vuelven polos."""
    cx, cy, cz = center
    rings = []
    for r, z in prof:
        if r < 1e-6:
            rings.append([bm.verts.new((cx, cy, cz + z))])
        else:
            rings.append([bm.verts.new((cx + r * math.sin(2 * math.pi * i / seg),
                                        cy - r * math.cos(2 * math.pi * i / seg), cz + z)) for i in range(seg)])
    faces = []
    for a, b in zip(rings[:-1], rings[1:]):
        if len(a) == 1 and len(b) > 1:
            for i in range(seg):
                faces.append(bm.faces.new((a[0], b[(i + 1) % seg], b[i])))
        elif len(b) == 1 and len(a) > 1:
            for i in range(seg):
                faces.append(bm.faces.new((a[i], a[(i + 1) % seg], b[0])))
        elif len(a) > 1 and len(b) > 1:
            for i in range(seg):
                faces.append(bm.faces.new((a[i], a[(i + 1) % seg], b[(i + 1) % seg], b[i])))
    return faces


def head_profile(R, H, rb, levels=(), n=7):
    p = [(0.0, -H / 2)]
    for i in range(n + 1):
        a = -math.pi / 2 + (math.pi / 2) * i / n
        p.append((R - rb + rb * math.cos(a), -H / 2 + rb + rb * math.sin(a)))
    z0, z1 = -H / 2 + rb, H / 2 - rb
    mids = sorted({round(z, 5) for z in list(levels) + [z0 + (z1 - z0) * k / 6 for k in range(1, 6)] if z0 < z < z1})
    p += [(R, z) for z in mids]
    for i in range(n + 1):
        a = (math.pi / 2) * i / n
        p.append((R - rb + rb * math.cos(a), H / 2 - rb + rb * math.sin(a)))
    p.append((0.0, H / 2))
    return p


def head_mesh(name):
    bm = bmesh.new()
    revolve(bm, head_profile(HEAD_R, HEAD_H, HEAD_RB), 64)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def grid_mesh(name, xs, ys, uv_fn=None):
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    V = [[bm.verts.new((x, y, 0.0)) for x in xs] for y in ys]
    for j in range(len(ys) - 1):
        for i in range(len(xs) - 1):
            f = bm.faces.new((V[j][i], V[j][i + 1], V[j + 1][i + 1], V[j + 1][i]))
            for l in f.loops:
                x, y, _ = l.vert.co
                l[uv].uv = uv_fn(x, y) if uv_fn else (x, y)
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def disc_mesh(name, rx, ry, rings=5, seg=40):
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    c = bm.verts.new((0, 0, 0))
    R = [[bm.verts.new((rx * k / rings * math.cos(2 * math.pi * i / seg), ry * k / rings * math.sin(2 * math.pi * i / seg), 0))
          for i in range(seg)] for k in range(1, rings + 1)]
    fs = [bm.faces.new((c, R[0][i], R[0][(i + 1) % seg])) for i in range(seg)]
    for a, b in zip(R[:-1], R[1:]):
        fs += [bm.faces.new((a[i], b[i], b[(i + 1) % seg], a[(i + 1) % seg])) for i in range(seg)]
    for f in fs:
        for l in f.loops:
            l[uv].uv = (l.vert.co.x, l.vert.co.y)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def fan_mesh(name, pts):
    """Polígono relleno (centro en abanico) con anillos internos para que se adapte a la cabeza."""
    bm = bmesh.new()
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    c = bm.verts.new((cx, cy, 0))
    rings = 3
    R = [[bm.verts.new((cx + (p[0] - cx) * k / rings, cy + (p[1] - cy) * k / rings, 0)) for p in pts]
         for k in range(1, rings + 1)]
    n = len(pts)
    for i in range(n):
        bm.faces.new((c, R[0][i], R[0][(i + 1) % n]))
    for a, b in zip(R[:-1], R[1:]):
        for i in range(n):
            bm.faces.new((a[i], b[i], b[(i + 1) % n], a[(i + 1) % n]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    uv = bm.loops.layers.uv.new("UVMap")
    for f in bm.faces:
        for l in f.loops:
            l[uv].uv = (l.vert.co.x, l.vert.co.y)
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def drop_pts(r=0.012, h=0.03, n=20):
    pts = []
    for i in range(n):
        a = math.pi * (-0.25 + 1.5 * i / (n - 1)) - math.pi / 2
        pts.append((r * math.cos(a), r * math.sin(a)))
    pts.append((0.0, h))
    return pts


# ------------------------------------------------------------------ boca (formas)
W0, TH = 0.058, 0.0105
BOCA_KEYS = kit_ui.BOCA


def _cap(s):
    return max(0.0, 1.0 - s ** 6) ** 0.5


def _e(s, p=0.5):
    return max(0.0, 1.0 - s * s) ** p


def mouth_shape(key, s):
    """Devuelve (x, arriba, abajo, centro) del contorno de la boca para el parámetro s en [-1, 1]."""
    h = TH / 2 * _cap(s)
    if key == "Sonrisa":
        xs, c = W0 * 1.15, 0.03 * s * s - 0.01
        return xs * s, c + h, c - h, c
    if key == "Triste":
        xs, c = W0 * 0.95, -0.026 * s * s + 0.008
        return xs * s, c + h, c - h, c
    if key == "Abierta":
        xs, e = W0 * 0.42, _e(s, 0.42)
        U, L = (0.03 + TH / 2) * e - 0.004, -(0.036 + TH / 2) * e - 0.004
        return xs * s, U, L, (U + L) / 2
    if key == "Risa":
        xs = W0 * 1.22
        U = 0.004 + 0.014 * s * s + h
        L = U - (0.06 * _e(s, 0.75) + TH * _cap(s))
        return xs * s, U, L, (U + L) / 2
    if key == "Mueca":
        xs, c = W0 * 1.45, 0.03 * s * s - 0.008
        hh = 0.017 * _e(s) + h
        return xs * s, c + hh, c - hh, c
    if key == "Grito":
        xs, e = W0 * 0.78, _e(s, 0.6)
        U, L = (0.028 + TH / 2) * e, -(0.085 + TH / 2) * e
        return xs * s, U, L, (U + L) / 2
    if key == "Nervioso":
        xs, c = W0 * 1.05, 0.006 * math.sin(3.2 * math.pi * s) - 0.004
        return xs * s, c + h, c - h, c
    if key == "Lengua":
        xs, c = W0 * 0.9, 0.012 * s * s - 0.004
        return xs * s, c + h, c - h, c
    return W0 * s, h, -h, 0.0


def teeth_up(key, s):
    f = {"Risa": 0.86, "Mueca": 0.93, "Grito": 0.7}.get(key, 0.9)
    x, U, L, c = mouth_shape(key, f * s)
    if key == "Risa":
        top = U - 0.0022
        return x, top, max(top - 0.013 * _e(s, 0.35), L + 0.003)
    if key == "Mueca":
        top = U - 0.0022
        return x, top, min(c + 0.0012, top)
    if key == "Grito":
        top = U - 0.002
        return x, top, top - 0.01 * _e(s)
    return x, c, c


def teeth_down(key, s):
    f = {"Mueca": 0.93, "Grito": 0.6}.get(key, 0.9)
    x, U, L, c = mouth_shape(key, f * s)
    if key == "Mueca":
        top = c - 0.0012
        return x, top, min(L + 0.0022, top)
    if key == "Grito":
        bot = L + 0.002
        return x, bot + 0.008 * _e(s), bot
    return x, c, c


def tongue(key, s):
    f = {"Risa": 0.5, "Abierta": 0.6, "Grito": 0.5, "Lengua": 0.42}.get(key, 0.5)
    x, U, L, c = mouth_shape(key, f * s)
    if key in ("Risa", "Abierta", "Grito"):
        hgt = {"Risa": 0.017, "Abierta": 0.016, "Grito": 0.026}[key]
        bot = L + 0.0025
        top = min(bot + hgt * _e(s), U - 0.012) if key == "Risa" else bot + hgt * _e(s)
        return x, max(top, bot), bot
    if key == "Lengua":
        return x, c, c - 0.032 * _e(s)
    return x, c, c


def strip_obj(name, fn, coll, nx=40, ny=3):
    ss = [-1 + 2 * i / nx for i in range(nx + 1)]

    def verts(key):
        out = []
        for j in range(ny + 1):
            for s in ss:
                x, top, bot = fn(key, s)[:3]
                out.append((x, bot + (top - bot) * j / ny, 0.0))
        return out
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    V = [bm.verts.new(co) for co in verts("Basis")]
    for j in range(ny):
        for i in range(nx):
            a = j * (nx + 1) + i
            f = bm.faces.new((V[a], V[a + 1], V[a + nx + 2], V[a + nx + 1]))
            for l in f.loops:
                k = l.vert.index if False else V.index(l.vert)
                l[uv].uv = ((k % (nx + 1)) / nx, (k // (nx + 1)) / ny)
    me = mesh_from_bm(bm, name)
    me.shade_smooth()
    ob = bpy.data.objects.new(name, me)
    coll.objects.link(ob)
    ob.shape_key_add(name="Basis")
    for k in BOCA_KEYS:
        kb = ob.shape_key_add(name=k, from_mix=False)
        for i, co in enumerate(verts(k)):
            kb.data[i].co = co
    return ob


# ------------------------------------------------------------------ materiales de cara
def mat_skin(name, skin):
    m, nt, b = new_mat(name, 0.5)
    b.inputs["Base Color"].default_value = lin(skin)
    m.diffuse_color = lin(skin)
    return m


def _xy(nt, obj=None):
    tc = node(nt, "ShaderNodeTexCoord")
    if obj is not None:
        tc.object = obj
    x, y, _ = sep(nt, tc.outputs["Object"])
    return x, y


def _ell(nt, x, y, a, b):
    return M(nt, "ADD", M(nt, "MULTIPLY", M(nt, "DIVIDE", x, a), M(nt, "DIVIDE", x, a)),
             M(nt, "MULTIPLY", M(nt, "DIVIDE", y, b), M(nt, "DIVIDE", y, b)))


def _alpha(m, nt, b, a):
    nt.links.new(a, b.inputs["Alpha"])
    try:
        m.surface_render_method = "DITHERED"
    except Exception:
        pass
    try:
        m.blend_method = "HASHED"
    except Exception:
        pass


def mat_eye(name, a, b, outline="#1a1a1e"):
    m, nt, bs = new_mat(name, 0.25)
    x, y = _xy(nt)
    e = _ell(nt, x, y, a, b)
    top = smooth(nt, 0.2 * b, b, y)
    col = mixc(nt, M(nt, "MULTIPLY", top, 0.12), lin("#ffffff"), lin("#c9d2df"))
    col = mixc(nt, M(nt, "GREATER_THAN", e, 1.0), col, lin(outline))
    nt.links.new(col, bs.inputs["Base Color"])
    m.diffuse_color = (1, 1, 1, 1)
    tidy(nt)
    return m


def mat_pupil(name, eye_obj, a, b, rp, color):
    m, nt, bs = new_mat(name, 0.2)
    x, y = _xy(nt)
    r = M(nt, "DIVIDE", M(nt, "SQRT", _ell(nt, x, y, 1.0, 1.0)), rp)
    col = mixc(nt, smooth(nt, 0.45, 1.0, r), lin(color), shade(color, 0.45))
    h1 = M(nt, "LESS_THAN", _ell(nt, M(nt, "SUBTRACT", x, 0.36 * rp), M(nt, "SUBTRACT", y, 0.38 * rp), 1.0, 1.0), (0.33 * rp) ** 2)
    h2 = M(nt, "LESS_THAN", _ell(nt, M(nt, "ADD", x, 0.32 * rp), M(nt, "ADD", y, 0.36 * rp), 1.0, 1.0), (0.13 * rp) ** 2)
    col = mixc(nt, M(nt, "MAXIMUM", h1, h2), col, lin("#ffffff"))
    nt.links.new(col, bs.inputs["Base Color"])
    ex, ey = _xy(nt, eye_obj)
    _alpha(m, nt, bs, M(nt, "LESS_THAN", _ell(nt, ex, ey, a, b), 1.0))
    m.diffuse_color = lin(color)
    tidy(nt)
    return m


def mat_lid(name, eye_obj, a, b, t, skin, line="#1a1a1e"):
    m, nt, bs = new_mat(name, 0.5)
    uvn = node(nt, "ShaderNodeUVMap")
    _, v, _ = sep(nt, uvn.outputs["UV"])
    col = mixc(nt, M(nt, "LESS_THAN", v, t * 1.05), lin(skin), lin(line))
    nt.links.new(col, bs.inputs["Base Color"])
    ex, ey = _xy(nt, eye_obj)
    _alpha(m, nt, bs, M(nt, "LESS_THAN", _ell(nt, ex, ey, a + t, b + t), 1.02))
    m.diffuse_color = lin(skin)
    tidy(nt)
    return m


def mat_soft(name, color, rx, ry, alpha=0.6):
    m, nt, bs = new_mat(name, 0.6)
    x, y = _xy(nt)
    r = M(nt, "SQRT", _ell(nt, x, y, rx, ry))
    bs.inputs["Base Color"].default_value = lin(color)
    _alpha(m, nt, bs, M(nt, "MULTIPLY", M(nt, "SUBTRACT", 1.0, smooth(nt, 0.35, 1.0, r)), alpha))
    try:
        m.surface_render_method = "BLENDED"
    except Exception:
        pass
    m.diffuse_color = lin(color)
    tidy(nt)
    return m


def mat_drop(name, color="#7cc6f5"):
    m, nt, bs = new_mat(name, 0.1)
    x, y = _xy(nt)
    hl = M(nt, "LESS_THAN", _ell(nt, M(nt, "ADD", x, 0.004), M(nt, "SUBTRACT", y, 0.004), 1.0, 1.0), 0.0035 ** 2)
    nt.links.new(mixc(nt, hl, lin(color), lin("#ffffff")), bs.inputs["Base Color"])
    m.diffuse_color = lin(color)
    tidy(nt)
    return m


def mat_teeth(name):
    m, nt, bs = new_mat(name, 0.3)
    uvn = node(nt, "ShaderNodeUVMap")
    u, v, _ = sep(nt, uvn.outputs["UV"])
    gap = M(nt, "LESS_THAN", M(nt, "PINGPONG", M(nt, "MULTIPLY", u, 9.0), 0.5), 0.06)
    col = mixc(nt, gap, lin("#fbfbf8"), lin("#9aa0a6"))
    nt.links.new(col, bs.inputs["Base Color"])
    m.diffuse_color = (1, 1, 1, 1)
    tidy(nt)
    return m


def mat_tongue(name):
    m, nt, bs = new_mat(name, 0.4)
    uvn = node(nt, "ShaderNodeUVMap")
    u, v, _ = sep(nt, uvn.outputs["UV"])
    mid = M(nt, "LESS_THAN", M(nt, "ABSOLUTE", M(nt, "SUBTRACT", u, 0.5)), 0.012)
    nt.links.new(mixc(nt, mid, lin("#ec7d90"), lin("#c45468")), bs.inputs["Base Color"])
    m.diffuse_color = lin("#ec7d90")
    tidy(nt)
    return m


def mat_hair(name, color):
    m, nt, b = new_mat(name, 0.45)
    tc = node(nt, "ShaderNodeTexCoord")
    w = node(nt, "ShaderNodeTexWave", {"Vector": tc.outputs["Object"], "Scale": 9.0, "Distortion": 3.0,
                                      "Detail": 2.0}, wave_type="BANDS", bands_direction="X")
    col = mixc(nt, M(nt, "MULTIPLY", w.outputs["Fac"], 0.5), lin(color), shade(color, 0.7))
    nt.links.new(col, b.inputs["Base Color"])
    bump = node(nt, "ShaderNodeBump", {"Strength": 0.25, "Distance": 0.01, "Height": w.outputs["Fac"]})
    nt.links.new(bump.outputs["Normal"], b.inputs["Normal"])
    b.inputs["Specular IOR Level"].default_value = 0.5
    m.diffuse_color = lin(color)
    tidy(nt)
    return m


def mat_body(name, skin, shirt_img, pants_img=None):
    """Piel + pantalón + camisa (las zonas transparentes de las imágenes dejan ver la piel)."""
    m, nt, b = new_mat(name, 0.6)
    uvn = node(nt, "ShaderNodeUVMap")
    col = lin(skin)
    if pants_img is not None:
        tp = node(nt, "ShaderNodeTexImage", {"Vector": uvn.outputs["UV"]}, image=pants_img, interpolation="Linear",
                  extension="EXTEND")
        col = mixc(nt, tp.outputs["Alpha"], col, tp.outputs["Color"])
    if shirt_img is not None:
        ts = node(nt, "ShaderNodeTexImage", {"Vector": uvn.outputs["UV"]}, image=shirt_img, interpolation="Linear",
                  extension="EXTEND")
        col = mixc(nt, ts.outputs["Alpha"], col, ts.outputs["Color"])
    nt.links.new(col, b.inputs["Base Color"])
    m.diffuse_color = lin(skin)
    tidy(nt)
    return m


# ------------------------------------------------------------------ widgets de huesos
def wgt(name, pts_list, closed=True):
    ob = bpy.data.objects.get(name)
    if ob:
        return ob
    bm = bmesh.new()
    for pts in pts_list:
        vs = [bm.verts.new(p) for p in pts]
        for i in range(len(vs) - (0 if closed else 1)):
            bm.edges.new((vs[i], vs[(i + 1) % len(vs)]))
    me = mesh_from_bm(bm, name)
    ob = bpy.data.objects.new(name, me)
    c = bpy.data.collections.get("WGT_Kit")
    if c is None:
        c = bpy.data.collections.new("WGT_Kit")
        bpy.context.scene.collection.children.link(c)
        c.hide_render = True
        c.hide_viewport = True
    c.objects.link(ob)
    return ob


def circ(r=1.0, n=32, plane="XY", cx=0.0, cy=0.0, a0=0.0, a1=2 * math.pi):
    pts = []
    for i in range(n):
        a = a0 + (a1 - a0) * i / (n if abs(a1 - a0 - 2 * math.pi) < 1e-6 else n - 1)
        u, v = cx + r * math.cos(a), cy + r * math.sin(a)
        pts.append((u, v, 0) if plane == "XY" else (u, 0, v))
    return pts


def widgets():
    return {
        "ring": wgt("WGT_Anillo", [circ(1.0, 32, "XZ")]),
        "root": wgt("WGT_Raiz", [circ(1.0, 48), [(-0.15, 1.0, 0), (0, 1.25, 0), (0.15, 1.0, 0)]]),
        "circle": wgt("WGT_Circulo", [circ(1.0, 24)]),
        "box": wgt("WGT_Cuadro", [[(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)]]),
        "brow": wgt("WGT_Ceja", [[(-1, -0.35, 0), (1, -0.35, 0), (1, 0.35, 0), (-1, 0.35, 0)]]),
        "lid_up": wgt("WGT_ParpadoSup", [circ(1.0, 16, "XY", 0, -0.6, 0.35, math.pi - 0.35)], closed=False),
        "lid_dn": wgt("WGT_ParpadoInf", [circ(1.0, 16, "XY", 0, 0.6, math.pi + 0.35, 2 * math.pi - 0.35)], closed=False),
        "mouth": wgt("WGT_Boca", [[(math.cos(a) * 1.0, math.sin(a) * 0.45, 0) for a in [2 * math.pi * i / 32 for i in range(32)]]]),
        "look": wgt("WGT_Mirada", [[(-1.6, -0.8, 0), (1.6, -0.8, 0), (1.6, 0.8, 0), (-1.6, 0.8, 0)],
                                   circ(0.55, 16, "XY", -0.8, 0), circ(0.55, 16, "XY", 0.8, 0)]),
        "face": wgt("WGT_Cara", [circ(1.0, 32), circ(0.12, 8, "XY", -0.35, 0.25), circ(0.12, 8, "XY", 0.35, 0.25),
                                 circ(0.55, 12, "XY", 0, 0.1, math.pi * 1.2, math.pi * 1.8)], closed=True),
    }


# ------------------------------------------------------------------ pelo, sombreros y accesorios
def hair_shell(mb, mat, fringe=0.13, side=-0.02, back=-0.16, front_deg=48, side_deg=115, grow=0.024, seg=48,
               top_only=False, ring=None):
    R, H = HEAD_R + grow, HEAD_H + grow * 1.4
    zc = HEAD_Z + grow * 0.45
    lv = [fringe, side, back]
    prof = head_profile(R, H, HEAD_RB + grow * 0.5, [z - grow * 0.45 for z in lv])
    bm = mb.bm
    faces = revolve(bm, prof, seg, (0, 0, zc))
    k = mb.mi(mat)
    kill = []
    for f in faces:
        c = f.calc_center_median()
        lz = c.z - HEAD_Z
        ang = abs(math.degrees(math.atan2(c.x, -c.y)))
        lim = fringe if ang < front_deg else (side if ang < side_deg else back)
        if top_only:
            lim = max(lim, HEAD_H / 2 - 0.03)
        if ring is not None:   # pelo solo alrededor (calvo arriba)
            if lz > ring or ang < 60:
                kill.append(f)
                continue
        if lz < lim or c.z < zc - H / 2 + 0.02:
            kill.append(f)
        else:
            f.material_index = k
    bmesh.ops.delete(bm, geom=kill, context="FACES")
    return [f for f in bm.faces if f.is_valid]


def solidify(ob, t=0.02):
    m = ob.modifiers.new("Grosor", "SOLIDIFY")
    m.thickness = t
    m.offset = -1
    m.use_even_offset = True


def build_hair(cfg, name, coll):
    h = cfg.get("hair")
    if not h:
        return []
    style, color = h["style"], h["color"]
    mh = mat_hair(name + "_Pelo", color)
    mb = MB()
    obs = []
    Z = HEAD_Z
    fm = cfg.get("_fmin", 0.0)       # el fleco nunca baja hasta las cejas
    fr = lambda f: max(f, fm)
    if style == "casco_largo":         # alcalde: melena tipo casco a los lados
        hair_shell(mb, mh, fringe=fr(0.13), side=-0.13, back=-0.2, front_deg=52)
    elif style == "corto":
        hair_shell(mb, mh, fringe=fr(0.14), side=0.0, back=-0.12)
    elif style == "despeinado":
        hair_shell(mb, mh, fringe=fr(0.12), side=0.0, back=-0.12)
        import random
        rnd = random.Random(len(name))
        for i in range(22):
            a = rnd.uniform(-2.7, 2.7)
            r = HEAD_R * rnd.uniform(0.2, 0.9)
            mb.box((r * math.sin(a), -r * math.cos(a), Z + 0.228 + rnd.uniform(-0.012, 0.012)), (0.085, 0.045, 0.07), mh,
                   bevel=0.012, segs=2, rot=(rnd.uniform(-0.3, 0.3), rnd.uniform(-0.3, 0.3), a))
        for i in range(6):
            x = -0.15 + i * 0.06
            mb.box((x, -0.215, Z + fr(0.12) + 0.025), (0.065, 0.04, 0.075), mh, bevel=0.01, segs=2,
                   rot=(0.35, 0, rnd.uniform(-0.35, 0.35)))
    elif style == "largo":
        hair_shell(mb, mh, fringe=fr(0.12), side=-0.05, back=-0.2, front_deg=50)
        mb.box((0, 0.16, Z - 0.26), (0.46, 0.11, 0.42), mh, bevel=0.04, segs=3)
        for sx in (-1, 1):
            mb.box((sx * 0.215, -0.05, Z - 0.2), (0.07, 0.14, 0.34), mh, bevel=0.025, segs=3)
    elif style == "coletas":
        hair_shell(mb, mh, fringe=fr(0.12), side=0.0, back=-0.12)
        tie = flat(name + "_Liga", h.get("tie", "#f06aa0"), 0.5)
        for sx in (-1, 1):
            mb.sphere((sx * 0.29, 0.04, Z - 0.03), 0.085, mh, s=(0.9, 0.9, 1.35))
            mb.cyl((sx * 0.25, 0.03, Z + 0.06), 0.035, 0.05, tie, rot=(0, sx * 0.7, 0))
    elif style == "chongo":
        hair_shell(mb, mh, fringe=fr(0.15), side=0.02, back=-0.1)
        mb.sphere((0, 0.1, Z + 0.24), 0.11, mh)
    elif style == "calvo_lados":
        hair_shell(mb, mh, fringe=0.0, side=-0.08, back=-0.12, ring=0.1)
        for i in range(9):
            a = math.radians(75 + i * 26.25)
            for zz in (0.03, 0.09):
                mb.sphere((HEAD_R * 1.05 * math.sin(a), -HEAD_R * 1.05 * math.cos(a), Z + zz), 0.05, mh)
    elif style == "rizado":
        hair_shell(mb, mh, fringe=fr(0.13), side=0.0, back=-0.12)
        for i in range(14):
            a = -2.4 + i * 0.37
            mb.sphere((0.21 * math.sin(a), -0.21 * math.cos(a), Z + 0.2 + 0.03 * math.sin(i * 1.7)), 0.07, mh)
        for i in range(7):
            mb.sphere((-0.15 + i * 0.05, 0.0, Z + 0.25), 0.07, mh)
    ob = mb.obj(name + "_Pelo", coll, smooth=40)
    solidify(ob, 0.018)
    obs.append(ob)
    return obs


def build_hat(cfg, name, coll):
    hat = cfg.get("hat")
    if not hat:
        return []
    Z = HEAD_Z + HEAD_H / 2
    t = hat["type"]
    c = hat.get("color", "#2a5aa8")
    mb = MB()
    m1 = flat(name + "_Sombrero", c, 0.5)
    if t == "policia":
        black = flat(name + "_Visera", "#16181d", 0.3)
        gold = flat(name + "_Placa", "#f2c94c", 0.3, 0.6)
        mb.cyl((0, 0, Z - 0.02), 0.245, 0.1, m1, segs=40)
        mb.cyl((0, 0, Z + 0.07), 0.275, 0.08, m1, r2=0.29, segs=40)
        mb.cyl((0, 0, Z - 0.035), 0.25, 0.035, black, segs=40)
        mb.prism([(-0.2, 0), (0.2, 0), (0.15, -0.14), (-0.15, -0.14)], 0.02, black, c=(0, -0.2, Z - 0.05),
                 rot=(math.radians(-80), 0, 0), axis="z")
        mb.box((0, -0.27, Z + 0.06), (0.06, 0.02, 0.07), gold, bevel=0.008, segs=2)
    elif t == "copa":
        gold = flat(name + "_Cinta", "#d8b04a", 0.4, 0.3)
        mb.cyl((0, 0, Z + 0.17), 0.19, 0.34, m1, segs=40)
        mb.cyl((0, 0, Z), 0.32, 0.025, m1, segs=48)
        mb.cyl((0, 0, Z + 0.06), 0.195, 0.06, gold, segs=40)
    elif t == "gorro":
        dk = flat(name + "_Doblez", hat.get("band", c), 0.7)
        mb.sphere((0, 0, Z - 0.06), 0.25, m1, s=(1, 1, 0.85))
        mb.cyl((0, 0, Z - 0.07), 0.255, 0.09, dk, segs=40)
    elif t == "chef":
        mb.cyl((0, 0, Z + 0.06), 0.215, 0.16, m1, segs=40)
        for i in range(7):
            a = 2 * math.pi * i / 7
            mb.sphere((0.13 * math.cos(a), 0.13 * math.sin(a), Z + 0.2), 0.11, m1)
        mb.sphere((0, 0, Z + 0.24), 0.13, m1)
    elif t == "enfermera":
        red = flat(name + "_Cruz", "#e0393e", 0.5)
        mb.box((0, -0.05, Z + 0.03), (0.3, 0.16, 0.1), m1, bevel=0.015, segs=2, rot=(0.25, 0, 0))
        mb.box((0, -0.14, Z + 0.06), (0.06, 0.012, 0.018), red, rot=(0.25, 0, 0))
        mb.box((0, -0.14, Z + 0.06), (0.018, 0.012, 0.06), red, rot=(0.25, 0, 0))
    elif t == "cartero":
        dk = flat(name + "_Visera", hat.get("visor", "#1d3563"), 0.4)
        mb.sphere((0, 0, Z - 0.02), 0.25, m1, s=(1, 1, 0.55))
        mb.prism([(-0.17, 0), (0.17, 0), (0.13, -0.15), (-0.13, -0.15)], 0.018, dk, c=(0, -0.2, Z - 0.05),
                 rot=(math.radians(-85), 0, 0), axis="z")
    elif t == "orejeras":
        band = flat(name + "_Diadema", hat.get("band", "#ffffff"), 0.5)
        for sx in (-1, 1):
            mb.cyl((sx * 0.245, 0, HEAD_Z + 0.0), 0.075, 0.06, m1, rot=(0, math.pi / 2, 0), segs=24)
        mb.torus((0, 0, HEAD_Z), 0.275, 0.014, band, rot=(math.pi / 2, 0, 0), arc=math.pi, seg=24)
    ob = mb.obj(name + "_Sombrero", coll, smooth=40)
    return [ob]


def build_glasses(cfg, name, coll, face):
    g = cfg.get("glasses")
    if not g:
        return []
    mb = MB()
    fr = flat(name + "_Armazon", g.get("color", "#c9a24a"), 0.3, 0.7)
    lens = new_mat(name + "_Lente", 0.05)[0]
    lb = lens.node_tree.nodes["BSDF"]
    lb.inputs["Base Color"].default_value = lin("#ffffff")
    lb.inputs["Alpha"].default_value = 0.18
    try:
        lens.surface_render_method = "BLENDED"
    except Exception:
        pass
    ex, ez = face["ex"], face["ez"]
    r = min(max(face["a"], face["b"]) + face["t"] + 0.008, ex - 0.009)
    y = -HEAD_R - 0.03
    for sx in (-1, 1):
        mb.torus((sx * ex, y, HEAD_Z + ez), r, 0.0065, fr, rot=(math.pi / 2, 0, 0), seg=40, rseg=8)
        mb.cyl((sx * ex, y, HEAD_Z + ez), r, 0.002, lens, rot=(math.pi / 2, 0, 0), segs=40)
        mb.box((sx * (ex + r + 0.03), -0.09, HEAD_Z + ez + 0.01), (0.012, 0.3, 0.012), fr, rot=(0, 0, sx * 0.25))
    mb.cyl((0, y, HEAD_Z + ez + 0.012), 0.006, 2 * (ex - r) + 0.01, fr, rot=(0, math.pi / 2, 0), segs=8)
    ob = mb.obj(name + "_Lentes", coll, smooth=40)
    return [ob]


def build_mustache(cfg, name, coll):
    mcfg = cfg.get("mustache")
    if not mcfg:
        return None
    big = [(-0.11, 0.0), (-0.165, 0.04), (-0.175, 0.07), (-0.135, 0.05), (-0.07, 0.035), (0.0, 0.045),
           (0.07, 0.035), (0.135, 0.05), (0.175, 0.07), (0.165, 0.04), (0.11, 0.0), (0.07, -0.022),
           (0.02, -0.018), (0.0, -0.008), (-0.02, -0.018), (-0.07, -0.022)]
    bushy = [(-0.13, -0.01), (-0.12, 0.03), (-0.06, 0.045), (0.0, 0.035), (0.06, 0.045), (0.12, 0.03),
             (0.13, -0.01), (0.1, -0.04), (0.05, -0.03), (0.0, -0.02), (-0.05, -0.03), (-0.1, -0.04)]
    k = mcfg.get("scale", 1.0)
    pts = [(x * k, z * k) for x, z in (big if mcfg["style"] == "grande" else bushy)]
    mb = MB()
    m = mat_hair(name + "_Bigote", mcfg["color"])
    vs = mb.prism(pts, 0.04, m, c=(0, 0, 0), axis="y")
    # doblar siguiendo la curvatura de la cabeza
    for v in vs:
        x = v.co.x
        v.co.y += (HEAD_R - math.sqrt(max(HEAD_R ** 2 - x * x, 0.0))) + FACE_Y - 0.012
        v.co.z += HEAD_Z + mcfg.get("z", -0.07)
    bmesh.ops.bevel(mb.bm, geom=mb.bm.edges[:], offset=0.006, segments=2, affect="EDGES", clamp_overlap=True)
    ob = mb.obj(name + "_Bigote", coll, smooth=35)
    return ob


def build_mayor_regalia(name, coll):
    """Banda presidencial, roseta y charreteras del alcalde."""
    yel = flat(name + "_BandaAmarilla", "#e6b52e", 0.45)
    blu = flat(name + "_BandaAzul", "#1f4fae", 0.45)
    gold = flat(name + "_Oro", "#e3b23c", 0.3, 0.6)
    out = []
    mb = MB()
    hx, hy, top, bot = 0.35, 0.175, TORSO_Z + 0.35, TORSO_Z - 0.35
    p0, p1 = Vector((0.27, top + 0.0)), Vector((-0.36, bot + 0.1))
    d = (p1 - p0).normalized()
    nrm = Vector((-d.y, d.x))
    widths = [(-0.05, -0.028, yel), (-0.028, 0.028, blu), (0.028, 0.05, yel)]
    for yy in (-hy - 0.012, hy + 0.012):
        for w0, w1, mat in widths:
            pts = [tuple(p0 + nrm * w0), tuple(p1 + nrm * w0), tuple(p1 + nrm * w1), tuple(p0 + nrm * w1)]
            mb.prism(pts, 0.018, mat, c=(0, yy, 0), axis="y")
    mb.box((0.27, 0, top + 0.01), (0.1, 2 * hy + 0.04, 0.02), yel)
    mb.box((-hx - 0.012, 0, bot + 0.1), (0.02, 2 * hy + 0.04, 0.1), yel)
    # roseta
    ry = -hy - 0.03
    rc = (-0.22, ry, bot + 0.16)
    mb.cyl(rc, 0.07, 0.02, gold, rot=(math.pi / 2, 0, 0), segs=32)
    mb.cyl((rc[0], ry - 0.012, rc[2]), 0.035, 0.012, blu, rot=(math.pi / 2, 0, 0), segs=24)
    for sx in (-1, 1):
        mb.prism([(0, 0), (0.035, 0), (0.035 + sx * 0.0, -0.14), (0.017, -0.115), (0.0, -0.14)], 0.01, gold,
                 c=(rc[0] - 0.017 + sx * 0.025, ry + 0.004, rc[2] - 0.02), rot=(0, sx * 0.25, 0), axis="y")
    out.append(mb.obj(name + "_Banda", coll, smooth=40))
    # charreteras
    eps = []
    for sx, side in ((1, "L"), (-1, "R")):
        mb = MB()
        mb.box((sx * 0.525, 0, TORSO_Z + 0.36), (0.38, 0.38, 0.045), gold, bevel=0.012, segs=2)
        for i in range(6):
            mb.cyl((sx * (0.525 + 0.17 * (1 if sx > 0 else -1)), -0.15 + i * 0.06, TORSO_Z + 0.32), 0.012, 0.07, gold, segs=8)
        eps.append((mb.obj(name + "_Charretera." + side, coll, smooth=40), "Brazo." + side))
    return out, eps


def build_skirt(cfg, name, coll):
    s = cfg.get("skirt")
    if not s:
        return None
    bm = bmesh.new()
    t, b = TORSO_Z - 0.33, 0.36
    tw, td, bw, bd = 0.73, 0.38, 0.86, 0.52
    vs = [bm.verts.new(p) for p in [(-tw / 2, -td / 2, t), (tw / 2, -td / 2, t), (tw / 2, td / 2, t), (-tw / 2, td / 2, t),
                                    (-bw / 2, -bd / 2, b), (bw / 2, -bd / 2, b), (bw / 2, bd / 2, b), (-bw / 2, bd / 2, b)]]
    for f in [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]:
        bm.faces.new([vs[i] for i in f])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bmesh.ops.bevel(bm, geom=bm.edges[:], offset=0.03, segments=3, affect="EDGES", clamp_overlap=True)
    me = mesh_from_bm(bm, name + "_Falda")
    me.materials.append(flat(name + "_Falda", s["color"], 0.7))
    me.shade_smooth()
    ob = bpy.data.objects.new(name + "_Falda", me)
    coll.objects.link(ob)
    add_weighted_normals(ob)
    return ob


def build_bag(cfg, name, coll):
    if not cfg.get("bag"):
        return None
    mb = MB()
    br = flat(name + "_Bolsa", "#8a5a33", 0.7)
    dk = flat(name + "_BolsaTapa", "#6d4425", 0.7)
    mb.box((-0.42, -0.02, 0.78), (0.12, 0.3, 0.26), br, bevel=0.02, segs=2)
    mb.box((-0.485, -0.02, 0.85), (0.02, 0.31, 0.13), dk, bevel=0.008, segs=2)
    ob = mb.obj(name + "_Bolsa", coll, smooth=40)
    return ob


# ------------------------------------------------------------------ rig
def build_rig(name, coll, face, has_mustache):
    data = bpy.data.armatures.new(name + "_Rig")
    data.display_type = "OCTAHEDRAL"
    rig = bpy.data.objects.new(name + "_Rig", data)
    coll.objects.link(rig)
    rig.show_in_front = True
    vl = bpy.context.view_layer
    vl.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    eb = data.edit_bones
    cols = {n: data.collections.new(n) for n in ("Cuerpo", "Cara", "Mecanismo")}

    def B(n, h, t, parent=None, col="Cuerpo"):
        b = eb.new(n)
        b.head, b.tail, b.roll = Vector(h), Vector(t), 0.0
        b.parent = eb.get(parent) if parent else None
        b.use_deform = False
        cols[col].assign(b)
        return b

    HZ = HEAD_Z
    ex, ez, a, b, t = face["ex"], face["ez"], face["a"], face["b"], face["t"]
    up = Vector((0, 0, 0.025))
    B("Raiz", (0, 0, 0), (0, 0.55, 0))
    B("Torso", (0, 0, TORSO_Z), (0, 0, 1.40), "Raiz")
    B("Cabeza", (0, 0, 1.40), (0, 0, 1.40 + HEAD_H + 0.05), "Torso")
    for sx, s in ((1, "L"), (-1, "R")):
        B("Brazo." + s, (sx * 0.525, 0, 1.225), (sx * 0.525, 0, 0.72), "Torso")
        B("Pierna." + s, (sx * 0.175, 0, 0.70), (sx * 0.175, 0, 0.02), "Torso")
    def F(n, x, z, parent, col="Cara", y=BONE_Y):
        p = Vector((x, y, HZ + z))
        return B(n, p, p + up, parent, col)
    F("Cara", 0.45, 0.12, "Cabeza", y=0.0)
    F("Mirada", 0.0, ez, "Cabeza", y=BONE_Y - 0.14)
    for sx, s in ((1, "L"), (-1, "R")):
        F("Ojo." + s, sx * ex, ez, "Cabeza")
        F("Pupila." + s, sx * ex, ez, "Ojo." + s)
        F("Parpado_Sup." + s, sx * ex, ez + b + t, "Ojo." + s)
        F("MCH_Parpado_Sup." + s, sx * ex, ez + b + t, "Parpado_Sup." + s, "Mecanismo")
        F("Parpado_Inf." + s, sx * ex, ez - b - t, "Ojo." + s)
        F("MCH_Parpado_Inf." + s, sx * ex, ez - b - t, "Parpado_Inf." + s, "Mecanismo")
        F("Ceja." + s, sx * ex, face["bz"], "Cabeza")
    F("Boca", 0.0, face["mz"], "Cabeza")
    if has_mustache:
        F("Bigote", 0.0, face.get("mustache_z", -0.07), "Cabeza")
    bpy.ops.object.mode_set(mode="OBJECT")
    cols["Mecanismo"].is_visible = False

    W = widgets()
    pbs = rig.pose.bones
    for pb in pbs:
        pb.rotation_mode = "XYZ"
    def shape(n, w, sc, tr=(0, 0, 0), color="THEME01"):
        pb = pbs[n]
        pb.custom_shape = W[w]
        pb.use_custom_shape_bone_size = False
        pb.custom_shape_scale_xyz = sc
        pb.custom_shape_translation = tr
        pb.color.palette = color
    shape("Raiz", "root", (0.75, 0.75, 0.75), color="THEME03")
    shape("Torso", "ring", (0.62, 0.62, 0.62), color="THEME04")
    shape("Cabeza", "ring", (0.36, 0.36, 0.36), (0, 0.06, 0), color="THEME04")
    for s in ("L", "R"):
        shape("Brazo." + s, "ring", (0.3, 0.3, 0.3), (0, 0.06, 0), color="THEME04")
        shape("Pierna." + s, "ring", (0.3, 0.3, 0.3), (0, 0.06, 0), color="THEME04")
        shape("Ojo." + s, "circle", (a + t + 0.012,) * 3, (0, 0, 0.02), color="THEME09")
        shape("Pupila." + s, "circle", (face["rp"] * 0.7,) * 3, (0, 0, 0.03), color="THEME02")
        shape("Parpado_Sup." + s, "lid_up", (a + t + 0.02,) * 3, (0, 0, 0.03), color="THEME11")
        shape("Parpado_Inf." + s, "lid_dn", (a + t + 0.02,) * 3, (0, 0, 0.03), color="THEME11")
        shape("Ceja." + s, "brow", (face["bl"] / 2 + 0.008,) * 3, (0, 0, 0.03), color="THEME09")
    shape("Boca", "mouth", (0.085, 0.085, 0.085), (0, 0, 0.03), color="THEME09")
    shape("Mirada", "look", (0.05, 0.05, 0.05), color="THEME02")
    shape("Cara", "face", (0.09, 0.09, 0.09), color="THEME09")
    if has_mustache:
        shape("Bigote", "brow", (0.12, 0.12, 0.12), (0, 0, 0.06), color="THEME09")

    # bloqueos: los controles de la cara se mueven sobre el plano de la cara
    face_bones = [p.name for p in pbs if p.bone.collections and p.bone.collections[0].name in ("Cara", "Mecanismo")]
    for n in face_bones:
        pb = pbs[n]
        pb.lock_location[2] = True
        pb.lock_rotation[0] = pb.lock_rotation[1] = True
        pb.lock_scale[2] = True
    for n in ("Cara", "Mirada"):
        pb = pbs[n]
        pb.lock_rotation = (True, True, True)
        pb.lock_scale = (True, True, True)
    pbs["Cara"].lock_location = (True, True, True)

    # propiedades de expresión
    cara = pbs["Cara"]
    for p in kit_ui.PROPS:
        cara[p] = 0.0
        ui = cara.id_properties_ui(p)
        ui.update(min=0.0, max=1.0, soft_min=0.0, soft_max=1.0, default=0.0)
        try:
            cara.property_overridable_library_set(f'["{p}"]', True)
        except Exception:
            pass

    # pupilas siguen a la mirada
    for s in ("L", "R"):
        pb = pbs["Pupila." + s]
        c = pb.constraints.new("COPY_LOCATION")
        c.target, c.subtarget = rig, "Mirada"
        c.use_offset = True
        c.target_space = c.owner_space = "LOCAL"
        c.use_z = False
        lim = pb.constraints.new("LIMIT_LOCATION")
        lim.owner_space = "LOCAL"
        for ax, v in (("x", a * 0.95), ("y", b * 0.95)):
            setattr(lim, "use_min_" + ax, True)
            setattr(lim, "use_max_" + ax, True)
            setattr(lim, "min_" + ax, -v)
            setattr(lim, "max_" + ax, v)

    # párpados manejados por Parpadeo / Ojos_Felices
    K1, K2, K3 = b + t, 1.3 * b + t, 0.7 * b + t
    for s, side in (("L", "L"), ("R", "R")):
        for n, expr in (("MCH_Parpado_Sup." + s, f"max(-{K2:.5f}, -{K1:.5f}*P - {K2:.5f}*F)"),
                        ("MCH_Parpado_Inf." + s, f"min({K1:.5f}, {K1:.5f}*P + {K3:.5f}*F)")):
            fc = pbs[n].driver_add("location", 1)
            d = fc.driver
            d.type = "SCRIPTED"
            for vn, prop in (("P", "Parpadeo_" + side), ("F", "Ojos_Felices")):
                v = d.variables.new()
                v.name, v.type = vn, "SINGLE_PROP"
                v.targets[0].id_type = "OBJECT"
                v.targets[0].id = rig
                v.targets[0].data_path = f'pose.bones["Cara"]["{prop}"]'
            d.expression = expr
    return rig


def drive(owner, path, index, rig, prop, expr="v"):
    fc = owner.driver_add(path, index) if index is not None else owner.driver_add(path)
    d = fc.driver
    d.type = "SCRIPTED"
    v = d.variables.new()
    v.name, v.type = "v", "SINGLE_PROP"
    v.targets[0].id_type = "OBJECT"
    v.targets[0].id = rig
    v.targets[0].data_path = f'pose.bones["Cara"]["{prop}"]'
    d.expression = expr
    return fc


def parent_to(ob, rig, bone):
    mw = ob.matrix_world.copy()
    ob.parent = rig
    ob.parent_type = "BONE"
    ob.parent_bone = bone
    bpy.context.view_layer.update()
    ob.matrix_world = mw


def shrink(ob, head, off, normals=False):
    m = ob.modifiers.new("Pegar_a_cabeza", "SHRINKWRAP")
    m.target = head
    m.wrap_method = "NEAREST_SURFACEPOINT"
    m.wrap_mode = "ABOVE_SURFACE"
    m.offset = off
    if normals:   # mismo sombreado que la cabeza (los párpados no se notan sobre la piel)
        dt = ob.modifiers.new("Normales_de_cabeza", "DATA_TRANSFER")
        dt.object = head
        dt.use_loop_data = True
        dt.data_types_loops = {"CUSTOM_NORMAL"}
        dt.loop_mapping = "POLYINTERP_NEAREST"


# ------------------------------------------------------------------ cara
def build_face(name, coll, rig, head, cfg, face):
    skin = cfg["skin"]
    a, b, t, rp, ex, ez = face["a"], face["b"], face["t"], face["rp"], face["ex"], face["ez"]
    parts = []

    def place(ob, x, z, bone, off_key):
        ob.matrix_world = Matrix.Translation((x, FACE_Y, HEAD_Z + z)) @ FACE_ROT
        parent_to(ob, rig, bone)
        shrink(ob, head, OFF[off_key], normals=off_key == "parpado")
        ob.visible_shadow = False      # son calcomanías: no deben dejar halo de sombra
        parts.append(ob)

    def new_ob(n, me, mats):
        for m in mats:
            me.materials.append(m)
        ob = bpy.data.objects.new(n, me)
        coll.objects.link(ob)
        return ob

    m_eye = mat_eye(name + "_Ojo", a, b)
    lw, lh = 2 * (a + t) + 0.03, 2 * (b + t) + 0.04
    nx = 14
    xs = [-lw / 2 + lw * i / nx for i in range(nx + 1)]
    for sx, s in ((1, "L"), (-1, "R")):
        eye = new_ob(f"{name}_Ojo.{s}", disc_mesh(f"{name}_Ojo.{s}", a + t, b + t), [m_eye])
        place(eye, sx * ex, ez, "Ojo." + s, "ojo")
        pup = new_ob(f"{name}_Pupila.{s}", disc_mesh(f"{name}_Pupila.{s}", rp, rp, 4, 32),
                     [mat_pupil(f"{name}_Pupila.{s}", eye, a, b, rp, face.get("pupil", "#1c1410"))])
        place(pup, sx * ex, ez, "Pupila." + s, "pupila")
        m_up = mat_lid(f"{name}_ParpadoSup.{s}", eye, a, b, t, skin)
        m_dn = mat_lid(f"{name}_ParpadoInf.{s}", eye, a, b, t, skin)
        ys = [lh * j / 6 for j in range(7)]
        up = new_ob(f"{name}_ParpadoSup.{s}", grid_mesh(f"{name}_ParpadoSup.{s}", xs, ys, lambda x, y: (x, y)), [m_up])
        dn = new_ob(f"{name}_ParpadoInf.{s}", grid_mesh(f"{name}_ParpadoInf.{s}", xs, [-y for y in ys[::-1]],
                                                          lambda x, y: (x, -y)), [m_dn])
        for lid in (up, dn):
            lid.shape_key_add(name="Basis")
            kb = lid.shape_key_add(name="Arco", from_mix=False)
            for i, v in enumerate(lid.data.vertices):
                x = v.co.x
                arc = 0.45 * b * max(0.0, 1.0 - (x / (a + t)) ** 2)
                kb.data[i].co = (x, v.co.y + arc, 0.0)
            drive(lid.data.shape_keys.key_blocks["Arco"], "value", None, rig, "Ojos_Felices")
        place(up, sx * ex, ez + b + t, "MCH_Parpado_Sup." + s, "parpado")
        place(dn, sx * ex, ez - b - t, "MCH_Parpado_Inf." + s, "parpado")
        # ceja
        bl, bt = face["bl"], face["bt"]
        pts = []
        for i in range(10):
            ang = math.pi / 2 + math.pi * i / 9
            pts.append((-bl / 2 + bt / 2 + bt / 2 * math.cos(ang), bt / 2 * math.sin(ang)))
        for i in range(10):
            ang = -math.pi / 2 + math.pi * i / 9
            pts.append((bl / 2 - bt / 2 + bt / 2 * math.cos(ang), bt / 2 * math.sin(ang)))
        brow = new_ob(f"{name}_Ceja.{s}", fan_mesh(f"{name}_Ceja.{s}", pts), [flat(name + "_Ceja", face["brow"], 0.6)])
        brow.shape_key_add(name="Basis")
        kb = brow.shape_key_add(name="Arco", from_mix=False)
        for i, v in enumerate(brow.data.vertices):
            kb.data[i].co = (v.co.x, v.co.y + 0.012 * (1 - (2 * v.co.x / bl) ** 2), 0)
        place(brow, sx * ex, face["bz"], "Ceja." + s, "ceja")
        brow.data.shape_keys.key_blocks["Arco"].value = face.get("brow_arc", 0.3)
        # rubor y lágrima
        rub = new_ob(f"{name}_Rubor.{s}", disc_mesh(f"{name}_Rubor.{s}", 0.05, 0.028, 3, 24),
                     [mat_soft("KIT_Rubor", "#ff6f8a", 0.05, 0.028, 0.55)])
        place(rub, sx * (ex + 0.025), ez - b - 0.03, "Cabeza", "rubor")
        for i in range(3):
            drive(rub, "scale", i, rig, "Rubor")
        tear = new_ob(f"{name}_Lagrima.{s}", fan_mesh(f"{name}_Lagrima.{s}", drop_pts(0.012, 0.03)), [mat_drop("KIT_Gota")])
        place(tear, sx * (ex + a * 0.7), ez - b - 0.008 + face.get("tear_dz", 0.0), "Ojo." + s, "gota")
        for i in range(3):
            drive(tear, "scale", i, rig, "Lagrimas")
    sweat = new_ob(f"{name}_Sudor", fan_mesh(f"{name}_Sudor", drop_pts(0.014, 0.036)), [mat_drop("KIT_Gota")])
    place(sweat, 0.165, face["bz"] - 0.01, "Cabeza", "gota")
    for i in range(3):
        drive(sweat, "scale", i, rig, "Sudor")
    # boca
    mz = face["mz"]
    m_mouth = flat("KIT_Boca", "#2a1517", 0.5)
    boca = strip_obj(f"{name}_Boca", lambda k, s: mouth_shape(k, s), coll)
    boca.data.materials.append(m_mouth)
    lengua = strip_obj(f"{name}_Lengua", tongue, coll, nx=24)
    lengua.data.materials.append(mat_tongue("KIT_Lengua"))
    d_up = strip_obj(f"{name}_DientesSup", teeth_up, coll, nx=24, ny=2)
    d_dn = strip_obj(f"{name}_DientesInf", teeth_down, coll, nx=24, ny=2)
    mt = mat_teeth("KIT_Dientes")
    d_up.data.materials.append(mt)
    d_dn.data.materials.append(mt)
    for ob, k in ((boca, "boca"), (lengua, "lengua"), (d_up, "dientes"), (d_dn, "dientes")):
        place(ob, 0.0, mz, "Boca", k)
        for key in BOCA_KEYS:
            drive(ob.data.shape_keys.key_blocks[key], "value", None, rig, key)
    return parts


# ------------------------------------------------------------------ personaje completo
DEFAULT_FACE = dict(a=0.04, b=0.052, t=0.0075, rp=0.024, ex=0.072, ez=0.012, mz=-0.1, bl=0.068, bt=0.0125)


def build_character(cfg, parent_coll):
    name = cfg["name"]
    coll = bpy.data.collections.new("CH_" + name)
    parent_coll.children.link(coll)
    face = dict(DEFAULT_FACE)
    face.update(cfg.get("face", {}))
    face.setdefault("bz", face["ez"] + face["b"] + 0.03)
    cfg["_fmin"] = face["bz"] + 0.042
    if cfg.get("mustache"):
        face["mustache_z"] = cfg["mustache"].get("z", -0.07)
    face.setdefault("brow", cfg.get("hair", {}).get("color", "#2b2118") if cfg.get("hair") else "#3a2a20")
    if face["brow"] in ("#e8e8ec", "#f1f1f1", "#ffffff"):
        face["brow"] = "#b9b9c2"

    # texturas de ropa
    tex_dir = os.path.join(KIT_DIR, "texturas", "ropa")
    sh, pa = KT.Sheet(), KT.Sheet()
    cfg["shirt"](sh)
    cfg["pants"](pa)
    p_sh = os.path.join(tex_dir, f"{name}_Camisa.png")
    p_pa = os.path.join(tex_dir, f"{name}_Pantalon.png")
    sh.save(p_sh, name + "_Camisa")
    pa.save(p_pa, name + "_Pantalon")
    img_sh = bpy.data.images.load(p_sh, check_existing=True)
    img_pa = bpy.data.images.load(p_pa, check_existing=True)

    skin = cfg["skin"]
    m_torso = mat_body(name + "_Torso", skin, img_sh, img_pa)
    m_arms = mat_body(name + "_Brazos", skin, img_sh, None)
    m_legs = mat_body(name + "_Piernas", skin, None, img_pa)
    m_skin = mat_skin(name + "_Piel", skin)

    def part(n, me, mat, loc):
        me.materials.append(mat)
        ob = bpy.data.objects.new(n, me)
        coll.objects.link(ob)
        ob.location = loc
        return ob

    torso = part(name + "_Torso", body_box(name + "_Torso", TORSO_S, KT.TORSO), m_torso, (0, 0, TORSO_Z))
    arm_l = part(name + "_Brazo.L", body_box(name + "_Brazo.L", LIMB_S, KT.LLIMB), m_arms, (0.525, 0, TORSO_Z))
    arm_r = part(name + "_Brazo.R", body_box(name + "_Brazo.R", LIMB_S, KT.RLIMB), m_arms, (-0.525, 0, TORSO_Z))
    leg_l = part(name + "_Pierna.L", body_box(name + "_Pierna.L", LIMB_S, KT.LLIMB), m_legs, (0.175, 0, 0.35))
    leg_r = part(name + "_Pierna.R", body_box(name + "_Pierna.R", LIMB_S, KT.RLIMB), m_legs, (-0.175, 0, 0.35))
    head = part(name + "_Cabeza", head_mesh(name + "_Cabeza"), m_skin, (0, 0, HEAD_Z))
    head.data.transform(Matrix.Translation((0, 0, 0)))
    for ob in (torso, arm_l, arm_r, leg_l, leg_r):
        add_weighted_normals(ob)

    mustache = build_mustache(cfg, name, coll)
    rig = build_rig(name, coll, face, mustache is not None)
    bpy.context.view_layer.update()
    for ob, bn in ((torso, "Torso"), (arm_l, "Brazo.L"), (arm_r, "Brazo.R"), (leg_l, "Pierna.L"),
                   (leg_r, "Pierna.R"), (head, "Cabeza")):
        parent_to(ob, rig, bn)
    for ob in build_hair(cfg, name, coll) + build_hat(cfg, name, coll) + build_glasses(cfg, name, coll, face):
        parent_to(ob, rig, "Cabeza")
    if mustache:
        parent_to(mustache, rig, "Bigote")
    for ob in (build_skirt(cfg, name, coll), build_bag(cfg, name, coll)):
        if ob:
            parent_to(ob, rig, "Torso")
    if cfg.get("mayor"):
        sash, eps = build_mayor_regalia(name, coll)
        for ob in sash:
            parent_to(ob, rig, "Torso")
        for ob, bn in eps:
            parent_to(ob, rig, bn)
        # sombrero de copa opcional (oculto)
        alt = build_hat({"hat": {"type": "copa", "color": "#4a3d8f"}}, name + "_Copa", coll)
        for ob in alt:
            parent_to(ob, rig, "Cabeza")
            ob.hide_viewport = ob.hide_render = True
            ob.hide_set(True)
    build_face(name, coll, rig, head, cfg, face)
    for ob in coll.objects:
        if ob is not rig and ob.type == "MESH":
            ob.hide_select = False
    rig["kit_personaje"] = name
    return rig, coll


# ------------------------------------------------------------------ perro (accesorio animable)
def build_dog(parent_coll, name="Perro", c1="#e39a4a", c2="#fff4e4"):
    coll = bpy.data.collections.new("CH_" + name)
    parent_coll.children.link(coll)
    m1, m2 = flat(name + "_Pelaje", c1, 0.8), flat(name + "_Panza", c2, 0.8)
    blk = flat(name + "_Negro", "#1a1414", 0.3)
    wht = flat(name + "_Brillo", "#ffffff", 0.2, emit=0.5)
    parts = {}

    def P(n, build):
        mb = MB()
        build(mb)
        ob = mb.obj(f"{name}_{n}", coll, smooth=40)
        parts[n] = ob
        return ob
    P("Cuerpo", lambda mb: (mb.box((0, 0, 0.42), (0.32, 0.62, 0.3), m1, 0.05, 3),
                            mb.box((0, -0.05, 0.33), (0.26, 0.5, 0.1), m2, 0.04, 2)))
    def head(mb):
        mb.box((0, -0.38, 0.66), (0.34, 0.3, 0.3), m1, 0.06, 3)
        mb.box((0, -0.56, 0.6), (0.18, 0.12, 0.13), m2, 0.035, 3)
        mb.box((0, -0.625, 0.645), (0.06, 0.03, 0.045), blk, 0.012, 2)
        for sx in (-1, 1):
            mb.box((sx * 0.12, -0.36, 0.84), (0.09, 0.06, 0.12), m1, 0.02, 2, rot=(0, sx * 0.2, 0))
            mb.sphere((sx * 0.075, -0.535, 0.71), 0.032, blk, s=(1, 0.5, 1.15))
            mb.sphere((sx * 0.065, -0.552, 0.725), 0.011, wht)
    P("Cabeza", head)
    for sx, s in ((1, "L"), (-1, "R")):
        for fy, f in ((-0.2, "Del"), (0.2, "Tras")):
            P(f"Pata{f}.{s}", lambda mb, sx=sx, fy=fy: (mb.box((sx * 0.1, fy, 0.16), (0.1, 0.1, 0.32), m1, 0.025, 2),
                                                         mb.box((sx * 0.1, fy - 0.01, 0.03), (0.11, 0.12, 0.06), m2, 0.02, 2)))
    P("Cola", lambda mb: mb.box((0, 0.36, 0.58), (0.07, 0.07, 0.24), m1, 0.025, 2, rot=(0.6, 0, 0)))
    data = bpy.data.armatures.new(name + "_Rig")
    rig = bpy.data.objects.new(name + "_Rig", data)
    coll.objects.link(rig)
    rig.show_in_front = True
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    eb = data.edit_bones

    def B(n, h, t, p=None):
        b = eb.new(n)
        b.head, b.tail = Vector(h), Vector(t)
        b.parent = eb.get(p) if p else None
        b.use_deform = False
    B("Raiz", (0, 0, 0), (0, 0.4, 0))
    B("Cuerpo", (0, 0, 0.42), (0, 0.3, 0.42), "Raiz")
    B("Cabeza", (0, -0.3, 0.55), (0, -0.3, 0.85), "Cuerpo")
    B("Cola", (0, 0.3, 0.5), (0, 0.42, 0.7), "Cuerpo")
    for sx, s in ((1, "L"), (-1, "R")):
        for fy, f in ((-0.2, "Del"), (0.2, "Tras")):
            B(f"Pata{f}.{s}", (sx * 0.1, fy, 0.32), (sx * 0.1, fy, 0.02), "Cuerpo")
    bpy.ops.object.mode_set(mode="OBJECT")
    W = widgets()
    for pb in rig.pose.bones:
        pb.rotation_mode = "XYZ"
        pb.custom_shape = W["root"] if pb.name == "Raiz" else W["ring"]
        pb.use_custom_shape_bone_size = False
        pb.custom_shape_scale_xyz = (0.5,) * 3 if pb.name == "Raiz" else ((0.25,) * 3 if pb.name in ("Cuerpo", "Cabeza") else (0.09,) * 3)
    bpy.context.view_layer.update()
    for n, ob in parts.items():
        parent_to(ob, rig, n if n in rig.pose.bones else "Cuerpo")
    return rig, coll


# ------------------------------------------------------------------ reparto
def _p(fn, *a, **k):
    return lambda sh: fn(sh, *a, **k)


CAST = [
    dict(name="Alcalde", skin="#efcfaa", mayor=True,
         hair=dict(style="casco_largo", color="#24252b"),
         mustache=dict(style="grande", color="#16161a", scale=0.85, z=-0.07),
         face=dict(brow="#16161a", bt=0.015, bl=0.075, pupil="#120e0c", brow_arc=0.1, ez=0.025, mz=-0.115,
                   tear_dz=0.03),
         shirt=_p(KT.shirt_suit, "#5e7398", "#ffffff", "#3c4b6c"),
         pants=_p(KT.pants, "#5e7398", "#26272c")),
    dict(name="Tomi", skin="#f0c79c",
         hair=dict(style="despeinado", color="#6b3f20"),
         face=dict(a=0.043, b=0.056, rp=0.022, pupil="#3b2414"),
         shirt=_p(KT.shirt_tee, "#9be05b", collar="#5aa83a", sleeve=0.86),
         pants=_p(KT.pants, "#6fa6de", "#f4f4f4", seams=True)),
    dict(name="Policia", skin="#7b4f35",
         hat=dict(type="policia", color="#2c5fb0"),
         face=dict(pupil="#120c08", brow="#1a1210"),
         shirt=_p(KT.shirt_police),
         pants=_p(KT.pants, "#24467f", "#17181c")),
    dict(name="Preso", skin="#d8a173",
         hat=dict(type="gorro", color="#f08a3a", band="#d26f22"),
         face=dict(brow="#3a2416", bt=0.014),
         shirt=_p(KT.shirt_jumpsuit),
         pants=_p(KT.pants, "#f08a3a", "#7a7f88")),
    dict(name="Abuela", skin="#f4d6bb",
         hair=dict(style="chongo", color="#e6e6ec"),
         glasses=dict(color="#c9a24a"),
         face=dict(a=0.036, b=0.046, rp=0.021, brow="#b4b4bf", pupil="#3d2a1c"),
         skirt=dict(color="#3e3a52"),
         shirt=_p(KT.shirt_cardigan, "#b9a6dc", "#ffffff", collar="#ffffff"),
         pants=_p(KT.skirt_legs, "#3e3a52", "#f4d6bb", "#5a3b2e")),
    dict(name="Abuelo", skin="#f1c9a3",
         hair=dict(style="calvo_lados", color="#f1f1f1"),
         mustache=dict(style="tupido", color="#f4f4f4", z=-0.078),
         glasses=dict(color="#d0a640"),
         face=dict(a=0.035, b=0.045, rp=0.02, brow="#c8c8d0", bt=0.016, pupil="#3d2a1c", ez=0.02, mz=-0.125),
         shirt=lambda sh: (KT.shirt_tee(sh, "#f6f6f2", collar="#dcdcd6", sleeve=0.45), KT.apron_front(sh.torso("F"))),
         pants=_p(KT.pants, "#6b4a32", "#3a2a20", apron="#e8873a")),
    dict(name="Maestra", skin="#f2cfae",
         hair=dict(style="largo", color="#1b1b20"),
         glasses=dict(color="#3a3a40"),
         face=dict(pupil="#2a1a12", brow="#1b1b20"),
         skirt=dict(color="#202024"),
         shirt=_p(KT.shirt_cardigan, "#f2c84b", "#ffffff"),
         pants=_p(KT.skirt_legs, "#202024", "#f2cfae", "#202024")),
    dict(name="Nina", skin="#f7d8c0",
         hair=dict(style="coletas", color="#f1cf68", tie="#ff8fbf"),
         hat=dict(type="orejeras", color="#f7a8c8", band="#ffffff"),
         face=dict(a=0.043, b=0.055, pupil="#2e5c8a", brow="#c9a548"),
         shirt=_p(KT.shirt_sweater, "#f6a9c8", heart="#ffffff"),
         pants=_p(KT.pants, "#f9cfe0", "#ffffff")),
    dict(name="Vecino", skin="#c98c62",
         hair=dict(style="despeinado", color="#141418"),
         face=dict(pupil="#1a120c", brow="#141418"),
         shirt=_p(KT.shirt_flannel),
         pants=_p(KT.pants, "#2f4c7e", "#3b2d24", seams=True)),
    dict(name="Vecina", skin="#e3b38d",
         hair=dict(style="largo", color="#5a3622"),
         face=dict(pupil="#3b2414", brow="#4a2c1a"),
         shirt=_p(KT.shirt_sweater, "#3f9c5f"),
         pants=_p(KT.pants, "#6e2434", "#2a2a2e")),
    dict(name="Panadero", skin="#f0c79c",
         hat=dict(type="chef", color="#fbfbfa"),
         mustache=dict(style="tupido", color="#5a3a24", z=-0.078),
         face=dict(pupil="#2a1a12", brow="#5a3a24", ez=0.03, mz=-0.125),
         shirt=_p(KT.shirt_chef),
         pants=_p(KT.pants, "#3c3c42", "#26272c")),
    dict(name="Enfermera", skin="#f4d4b8",
         hair=dict(style="corto", color="#f0d27a"),
         hat=dict(type="enfermera", color="#ffffff"),
         face=dict(pupil="#2a6a6a", brow="#c9a548"),
         shirt=_p(KT.shirt_nurse),
         pants=_p(KT.pants, "#e4eef9", "#ffffff")),
    dict(name="Cartero", skin="#d29a6c",
         hair=dict(style="corto", color="#4a2e1c"),
         hat=dict(type="cartero", color="#2f6fc4", visor="#1d3563"),
         face=dict(pupil="#2a1a12", brow="#4a2e1c"),
         bag=True,
         shirt=_p(KT.shirt_mail, "#8ec1ea"),
         pants=_p(KT.pants, "#24457a", "#2a2a2e")),
    dict(name="Plantilla", skin="#f0c9a0",
         face=dict(),
         shirt=_p(KT.shirt_tee, "#c9ced6", sleeve=0.45),
         pants=_p(KT.pants, "#5a6a85", "#2a2a2e")),
]
