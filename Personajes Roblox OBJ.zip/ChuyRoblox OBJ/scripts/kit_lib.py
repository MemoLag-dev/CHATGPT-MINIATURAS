"""Utilidades compartidas del Kit Pueblo: colecciones, mallas por bmesh y nodos de material."""
import bpy, bmesh, math
from mathutils import Vector, Matrix, Euler


# ---------------------------------------------------------------- color
def srgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def lin(h, a=1.0):
    def f(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = srgb(h)
    return (f(r), f(g), f(b), a)


def shade(h, k):
    """Oscurece/aclara un color hex (k<1 oscurece) y devuelve color lineal."""
    c = lin(h)
    return (min(c[0] * k, 1), min(c[1] * k, 1), min(c[2] * k, 1), 1.0)


# ---------------------------------------------------------------- colecciones
def coll(name, parent=None, scene=None):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
        if parent is None:
            (scene or bpy.context.scene).collection.children.link(c)
        else:
            parent.children.link(c)
    return c


def put(ob, collection):
    for c in list(ob.users_collection):
        c.objects.unlink(ob)
    collection.objects.link(ob)
    return ob


# ---------------------------------------------------------------- mallas
class MB:
    """Constructor de mallas: acumula primitivas en un bmesh con índices de material."""

    def __init__(self):
        self.bm = bmesh.new()
        self.mats = []

    def mi(self, mat):
        if mat not in self.mats:
            self.mats.append(mat)
        return self.mats.index(mat)

    def _tag(self, verts, mat):
        i = self.mi(mat)
        faces = {f for v in verts for f in v.link_faces}
        for f in faces:
            f.material_index = i
        return faces

    @staticmethod
    def _mat4(c, rot, s=(1, 1, 1)):
        R = Euler(rot).to_matrix().to_4x4() if rot else Matrix()
        return Matrix.Translation(Vector(c)) @ R @ Matrix.Diagonal((s[0], s[1], s[2], 1.0))

    def box(self, c, s, mat, bevel=0.0, segs=1, rot=None):
        verts = bmesh.ops.create_cube(self.bm, size=1.0)["verts"]
        bmesh.ops.transform(self.bm, matrix=self._mat4(c, rot, s), verts=verts)
        self._tag(verts, mat)
        if bevel > 0:
            edges = list({e for v in verts for e in v.link_edges})
            bmesh.ops.bevel(self.bm, geom=edges, offset=bevel, segments=segs, affect="EDGES",
                            profile=0.5, clamp_overlap=True)
        return verts

    def box_mm(self, mn, mx, mat, bevel=0.0, segs=1):
        c = [(a + b) / 2 for a, b in zip(mn, mx)]
        s = [abs(b - a) for a, b in zip(mn, mx)]
        return self.box(c, s, mat, bevel, segs)

    def cyl(self, c, r, h, mat, segs=24, r2=None, rot=None, caps=True):
        verts = bmesh.ops.create_cone(self.bm, cap_ends=caps, cap_tris=False, segments=segs,
                                      radius1=r, radius2=r if r2 is None else r2, depth=h,
                                      matrix=self._mat4(c, rot))["verts"]
        self._tag(verts, mat)
        return verts

    def sphere(self, c, r, mat, u=24, v=12, s=(1, 1, 1), rot=None):
        verts = bmesh.ops.create_uvsphere(self.bm, u_segments=u, v_segments=v, radius=r,
                                          matrix=self._mat4(c, rot, s))["verts"]
        self._tag(verts, mat)
        return verts

    def prism(self, pts, depth, mat, c=(0, 0, 0), rot=None, axis="y"):
        """Extruye un polígono 2D. axis='y': puntos en XZ, grosor en Y."""
        M = self._mat4(c, rot)
        if axis == "y":
            p3 = lambda p, d: Vector((p[0], d, p[1]))
        elif axis == "x":
            p3 = lambda p, d: Vector((d, p[0], p[1]))
        else:
            p3 = lambda p, d: Vector((p[0], p[1], d))
        bm = self.bm
        a = [bm.verts.new(M @ p3(p, -depth / 2)) for p in pts]
        b = [bm.verts.new(M @ p3(p, depth / 2)) for p in pts]
        n = len(pts)
        faces = [bm.faces.new(a[::-1]), bm.faces.new(b)]
        for i in range(n):
            j = (i + 1) % n
            faces.append(bm.faces.new((a[i], a[j], b[j], b[i])))
        i = self.mi(mat)
        for f in faces:
            f.material_index = i
        bmesh.ops.recalc_face_normals(bm, faces=faces)
        return a + b

    def torus(self, c, R, r, mat, seg=32, rseg=10, rot=None, arc=2 * math.pi):
        M = self._mat4(c, rot)
        bm = self.bm
        closed = abs(arc - 2 * math.pi) < 1e-6
        n = seg if closed else seg + 1
        rings = []
        for i in range(n):
            t = arc * i / seg
            ring = []
            for j in range(rseg):
                p = 2 * math.pi * j / rseg
                x = (R + r * math.cos(p)) * math.cos(t)
                y = (R + r * math.cos(p)) * math.sin(t)
                z = r * math.sin(p)
                ring.append(bm.verts.new(M @ Vector((x, y, z))))
            rings.append(ring)
        k = self.mi(mat)
        for i in range(n if closed else n - 1):
            a, b = rings[i], rings[(i + 1) % n]
            for j in range(rseg):
                f = bm.faces.new((a[j], a[(j + 1) % rseg], b[(j + 1) % rseg], b[j]))
                f.material_index = k
        return [v for r_ in rings for v in r_]

    def obj(self, name, collection, smooth=None, recalc=False):
        me = bpy.data.meshes.new(name)
        if recalc:
            bmesh.ops.recalc_face_normals(self.bm, faces=self.bm.faces[:])
        self.bm.to_mesh(me)
        self.bm.free()
        for m in self.mats:
            me.materials.append(m)
        if smooth is not None:
            me.shade_smooth()
            me.set_sharp_from_angle(angle=math.radians(smooth))
        ob = bpy.data.objects.new(name, me)
        collection.objects.link(ob)
        return ob


# ---------------------------------------------------------------- nodos
def _sock(sockets, key):
    if isinstance(key, int):
        return sockets[key]
    for s in sockets:
        if s.identifier == key:
            return s
    return sockets[key]


def node(nt, typ, inputs=None, **props):
    n = nt.nodes.new(typ)
    for k, v in props.items():
        setattr(n, k, v)
    for k, v in (inputs or {}).items():
        setv(nt, _sock(n.inputs, k), v)
    return n


def setv(nt, sock, v):
    if isinstance(v, bpy.types.NodeSocket):
        nt.links.new(v, sock)
    elif v is not None:
        sock.default_value = v


def M(nt, op, a, b=0.0, c=None, clamp=False):
    n = nt.nodes.new("ShaderNodeMath")
    n.operation = op
    n.use_clamp = clamp
    setv(nt, n.inputs[0], a)
    setv(nt, n.inputs[1], b)
    if c is not None:
        setv(nt, n.inputs[2], c)
    return n.outputs[0]


def VM(nt, op, a, b=None, s=None):
    n = nt.nodes.new("ShaderNodeVectorMath")
    n.operation = op
    setv(nt, n.inputs[0], a)
    if b is not None:
        setv(nt, n.inputs[1], b)
    if s is not None:
        setv(nt, _sock(n.inputs, "Scale"), s)
    return n.outputs["Value"] if op in ("DOT_PRODUCT", "LENGTH", "DISTANCE") else n.outputs["Vector"]


def mixc(nt, fac, a, b):
    n = nt.nodes.new("ShaderNodeMix")
    n.data_type = "RGBA"
    setv(nt, _sock(n.inputs, "Factor_Float"), fac)
    setv(nt, _sock(n.inputs, "A_Color"), a)
    setv(nt, _sock(n.inputs, "B_Color"), b)
    return _sock(n.outputs, "Result_Color")


def sep(nt, v):
    n = nt.nodes.new("ShaderNodeSeparateXYZ")
    setv(nt, n.inputs[0], v)
    return n.outputs["X"], n.outputs["Y"], n.outputs["Z"]


def comb(nt, x=0.0, y=0.0, z=0.0):
    n = nt.nodes.new("ShaderNodeCombineXYZ")
    setv(nt, n.inputs[0], x)
    setv(nt, n.inputs[1], y)
    setv(nt, n.inputs[2], z)
    return n.outputs[0]


def smooth(nt, e0, e1, x):
    n = nt.nodes.new("ShaderNodeMapRange")
    n.interpolation_type = "SMOOTHSTEP"
    setv(nt, _sock(n.inputs, "Value"), x)
    setv(nt, _sock(n.inputs, "From Min"), e0)
    setv(nt, _sock(n.inputs, "From Max"), e1)
    return _sock(n.outputs, "Result")


def new_mat(name, rough=0.6):
    m = bpy.data.materials.get(name)
    if m:
        return m, m.node_tree, m.node_tree.nodes.get("BSDF")
    m = bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.name = "BSDF"
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Specular IOR Level"].default_value = 0.35
    nt.links.new(bsdf.outputs[0], out.inputs[0])
    return m, nt, bsdf


def flat(name, hexcol, rough=0.6, metal=0.0, emit=0.0, emit_col=None):
    m, nt, b = new_mat(name, rough)
    if b is None:
        return m
    b.inputs["Base Color"].default_value = lin(hexcol)
    b.inputs["Metallic"].default_value = metal
    if emit:
        b.inputs["Emission Color"].default_value = lin(emit_col or hexcol)
        b.inputs["Emission Strength"].default_value = emit
    m.diffuse_color = lin(hexcol)
    return m


def tidy(nt):
    """Acomoda nodos en columnas por profundidad (solo estética para el editor)."""
    depth = {}
    out = [n for n in nt.nodes if n.type in ("OUTPUT_MATERIAL", "OUTPUT_WORLD", "GROUP_OUTPUT")]

    def walk(n, d):
        if depth.get(n, -1) >= d:
            return
        depth[n] = d
        for s in n.inputs:
            for l in s.links:
                walk(l.from_node, d + 1)
    for o in out:
        walk(o, 0)
    cols = {}
    for n, d in depth.items():
        cols.setdefault(d, []).append(n)
    for d, ns in cols.items():
        for i, n in enumerate(ns):
            n.location = (-d * 220, -i * 180)


# ---------------------------------------------------------------- coordenadas triplanares
def coord_group():
    """Grupo que devuelve coordenadas de mundo proyectadas según la cara (u=horizontal, v=vertical)."""
    g = bpy.data.node_groups.get("KIT_CoordMundo")
    if g:
        return g
    g = bpy.data.node_groups.new("KIT_CoordMundo", "ShaderNodeTree")
    g.interface.new_socket(name="Vector", in_out="OUTPUT", socket_type="NodeSocketVector")
    nt = g
    go = nt.nodes.new("NodeGroupOutput")
    geo = nt.nodes.new("ShaderNodeNewGeometry")
    px, py, pz = sep(nt, geo.outputs["Position"])
    nx, ny, nz = sep(nt, geo.outputs["True Normal"])
    ax, ay, az = M(nt, "ABSOLUTE", nx), M(nt, "ABSOLUTE", ny), M(nt, "ABSOLUTE", nz)
    side_x = M(nt, "GREATER_THAN", ax, ay)          # pared mirando a X
    horiz = M(nt, "GREATER_THAN", az, 0.7)          # piso o techo
    u_wall = mixc_f(nt, side_x, px, py)
    u = mixc_f(nt, horiz, u_wall, px)
    v = mixc_f(nt, horiz, pz, py)
    w = mixc_f(nt, horiz, mixc_f(nt, side_x, py, px), pz)
    nt.links.new(comb(nt, u, v, w), go.inputs[0])
    return g


def mixc_f(nt, fac, a, b):
    n = nt.nodes.new("ShaderNodeMix")
    n.data_type = "FLOAT"
    setv(nt, _sock(n.inputs, "Factor_Float"), fac)
    setv(nt, _sock(n.inputs, "A_Float"), a)
    setv(nt, _sock(n.inputs, "B_Float"), b)
    return _sock(n.outputs, "Result_Float")


def coords(nt):
    g = nt.nodes.new("ShaderNodeGroup")
    g.node_tree = coord_group()
    return g.outputs[0]


def night_fac(nt):
    """Lee la propiedad 'noche' de la escena (0 = día, 1 = noche)."""
    a = node(nt, "ShaderNodeAttribute", attribute_type="VIEW_LAYER", attribute_name="noche")
    return a.outputs["Fac"]
