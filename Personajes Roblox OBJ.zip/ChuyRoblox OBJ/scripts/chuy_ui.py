# Kit ChuyMinesitoo - Panel de cara y poses
# Vista 3D > barra lateral (tecla N) > pestaña "Kit Chuy".
# Si no aparece al abrir el archivo: Editor de Texto > este archivo > "Run Script".
import bpy
from bpy.props import StringProperty, BoolProperty

GRUPOS = {
    "Boca": ["Sonrisa", "Triste", "Plana", "Abierta", "Risa", "Mueca", "Grito", "Nervioso", "Lengua", "Gato", "Puchero"],
    "Ojos": ["Parpadeo_L", "Parpadeo_R", "Ojos_Felices", "Ojos_Tristes", "Ojos_Enojados", "Ojos_Entrecerrados",
             "Ojos_Grandes", "Brillo"],
    "Ojos especiales": ["Corazones", "Estrellas", "Espirales", "Ojos_X"],
    "Extras": ["Cejas", "Rubor", "Pena", "Lagrimas", "Llanto", "Sudor", "Venita", "Lineas_Shock"],
}
PROPS = [p for g in GRUPOS.values() for p in g]
BOCA = GRUPOS["Boca"]

HUESOS_CARA = ["Mirada", "Ojo.L", "Ojo.R", "Pupila.L", "Pupila.R", "Ceja.L", "Ceja.R", "Boca"]

ENOJO_CEJAS = {"Ceja.L": {"loc": (0, -0.004), "rot": 0.45}, "Ceja.R": {"loc": (0, -0.004), "rot": -0.45}}
TRISTE_CEJAS = {"Ceja.L": {"loc": (0, 0.004), "rot": -0.4}, "Ceja.R": {"loc": (0, 0.004), "rot": 0.4}}

# p = propiedades del hueso "Cara"; b = huesos (loc en metros sobre el plano de la cara, rot en radianes, esc)
EXPRESIONES = {
    "Neutral": {},
    "Feliz": {"p": {"Sonrisa": 1.0, "Brillo": 1.0}},
    "Muy feliz": {"p": {"Risa": 1.0, "Ojos_Felices": 1.0, "Rubor": 0.6}},
    "Tierno": {"p": {"Gato": 1.0, "Ojos_Felices": 1.0, "Rubor": 1.0}},
    "Triste": {"p": {"Triste": 1.0, "Ojos_Tristes": 1.0, "Cejas": 1.0},
               "b": dict(TRISTE_CEJAS, Mirada={"loc": (0, -0.006)})},
    "Llorando": {"p": {"Grito": 0.45, "Triste": 0.55, "Ojos_Tristes": 1.0, "Cejas": 1.0, "Llanto": 1.0, "Lagrimas": 1.0},
                 "b": TRISTE_CEJAS},
    "Enojado": {"p": {"Triste": 0.7, "Ojos_Enojados": 1.0, "Cejas": 1.0, "Venita": 1.0}, "b": ENOJO_CEJAS},
    "Furioso": {"p": {"Grito": 0.55, "Mueca": 0.45, "Ojos_Enojados": 1.0, "Cejas": 1.0, "Venita": 1.0},
                "b": {"Ceja.L": {"loc": (0, -0.006), "rot": 0.6}, "Ceja.R": {"loc": (0, -0.006), "rot": -0.6}}},
    "Sorprendido": {"p": {"Abierta": 1.0, "Ojos_Grandes": 1.0, "Cejas": 1.0},
                    "b": {"Ceja.L": {"loc": (0, 0.01)}, "Ceja.R": {"loc": (0, 0.01)},
                          "Pupila.L": {"esc": (0.85, 0.85)}, "Pupila.R": {"esc": (0.85, 0.85)}}},
    "Asustado": {"p": {"Grito": 0.5, "Nervioso": 0.5, "Ojos_Grandes": 1.0, "Cejas": 1.0, "Sudor": 1.0, "Lineas_Shock": 1.0},
                 "b": {"Ceja.L": {"loc": (0, 0.01), "rot": -0.35}, "Ceja.R": {"loc": (0, 0.01), "rot": 0.35},
                       "Pupila.L": {"esc": (0.6, 0.6)}, "Pupila.R": {"esc": (0.6, 0.6)}}},
    "Nervioso": {"p": {"Nervioso": 1.0, "Sudor": 1.0, "Cejas": 1.0},
                 "b": {"Ceja.L": {"loc": (0, 0.004), "rot": -0.25}, "Ceja.R": {"loc": (0, 0.004), "rot": 0.25},
                       "Mirada": {"loc": (0.008, 0)}}},
    "Sospechoso": {"p": {"Ojos_Entrecerrados": 1.0, "Plana": 0.6, "Sonrisa": 0.3, "Cejas": 1.0},
                   "b": {"Ceja.L": {"loc": (0, -0.003), "rot": 0.2}, "Ceja.R": {"loc": (0, 0.006), "rot": 0.1},
                         "Mirada": {"loc": (0.009, 0)}, "Boca": {"loc": (0.004, 0), "rot": 0.2}}},
    "Malvado": {"p": {"Mueca": 1.0, "Ojos_Enojados": 0.6, "Ojos_Entrecerrados": 0.4, "Cejas": 1.0}, "b": ENOJO_CEJAS},
    "Enamorado": {"p": {"Corazones": 1.0, "Sonrisa": 1.0, "Rubor": 1.0}},
    "Emocionado": {"p": {"Estrellas": 1.0, "Risa": 1.0, "Rubor": 0.4}},
    "Mareado": {"p": {"Espirales": 1.0, "Nervioso": 1.0}},
    "Noqueado": {"p": {"Ojos_X": 1.0, "Lengua": 1.0, "Abierta": 0.3}},
    "Dormido": {"p": {"Parpadeo_L": 1.0, "Parpadeo_R": 1.0, "Puchero": 0.7}},
    "Avergonzado": {"p": {"Pena": 1.0, "Rubor": 1.0, "Ojos_Felices": 0.6, "Nervioso": 0.5},
                    "b": {"Mirada": {"loc": (-0.006, -0.005)}}},
    "Guiño": {"p": {"Parpadeo_R": 1.0, "Lengua": 1.0, "Sonrisa": 0.6, "Brillo": 1.0}},
    "Pensativo": {"p": {"Puchero": 0.8, "Cejas": 1.0},
                  "b": {"Mirada": {"loc": (0.007, 0.007)}, "Ceja.L": {"loc": (0, 0.008), "rot": -0.1},
                        "Ceja.R": {"loc": (0, -0.002), "rot": 0.15}, "Boca": {"loc": (0.006, 0)}}},
}

HUESOS_CUERPO = ["Cadera", "Torso_Inf", "Torso_Sup", "Cabeza", "Brazo_Sup.L", "Brazo_Sup.R", "Brazo_Inf.L",
                 "Brazo_Inf.R", "Mano.L", "Mano.R", "Pierna_Sup.L", "Pierna_Sup.R", "Pierna_Inf.L", "Pierna_Inf.R",
                 "Pie_IK.L", "Pie_IK.R"]

# rot = (x, y, z) en radianes; loc = (x, y, z) en metros (espacio del hueso)
POSES = {
    "Reposo": {},
    "Saludar": {"Brazo_Sup.R": {"rot": (0.0, 0.0, 2.5)}, "Brazo_Inf.R": {"rot": (0.0, 0.0, 0.5)},
                "Cabeza": {"rot": (0.0, 0.0, 0.15)}, "Brazo_Sup.L": {"rot": (0.0, 0.0, -0.1)}},
    "Festejar": {"Brazo_Sup.L": {"rot": (0.0, 0.0, -2.7)}, "Brazo_Sup.R": {"rot": (0.0, 0.0, 2.7)},
                 "Brazo_Inf.L": {"rot": (0.0, 0.0, -0.3)}, "Brazo_Inf.R": {"rot": (0.0, 0.0, 0.3)},
                 "Torso_Sup": {"rot": (0.12, 0.0, 0.0)}, "Cabeza": {"rot": (0.15, 0.0, 0.0)}},
    "Pensar": {"Brazo_Sup.R": {"rot": (-0.7, 0.0, 0.25)}, "Brazo_Inf.R": {"rot": (-2.0, 0.0, -0.3)},
               "Brazo_Sup.L": {"rot": (-0.5, 0.0, -0.35)}, "Brazo_Inf.L": {"rot": (-1.5, 0.0, 0.5)},
               "Cabeza": {"rot": (0.1, 0.0, 0.2)}},
    "Susto": {"Brazo_Sup.L": {"rot": (-0.6, 0.0, -1.2)}, "Brazo_Sup.R": {"rot": (-0.6, 0.0, 1.2)},
              "Brazo_Inf.L": {"rot": (-1.2, 0.0, 0.0)}, "Brazo_Inf.R": {"rot": (-1.2, 0.0, 0.0)},
              "Torso_Sup": {"rot": (0.15, 0.0, 0.0)}, "Cadera": {"loc": (0.0, 0.0, -0.03)}},
    "Caminar A": {"Pie_IK.L": {"loc": (0.0, -0.16, 0.0)}, "Pie_IK.R": {"loc": (0.0, 0.16, 0.06)},
                  "Brazo_Sup.L": {"rot": (0.45, 0.0, 0.0)}, "Brazo_Sup.R": {"rot": (-0.45, 0.0, 0.0)},
                  "Cadera": {"loc": (0.0, 0.0, -0.02)}},
    "Caminar B": {"Pie_IK.L": {"loc": (0.0, 0.16, 0.06)}, "Pie_IK.R": {"loc": (0.0, -0.16, 0.0)},
                  "Brazo_Sup.L": {"rot": (-0.45, 0.0, 0.0)}, "Brazo_Sup.R": {"rot": (0.45, 0.0, 0.0)},
                  "Cadera": {"loc": (0.0, 0.0, -0.02)}},
    "Sentado": {"_ik": 0.0, "Cadera": {"loc": (0.0, 0.0, -0.3)},
                "Pierna_Sup.L": {"rot": (-1.55, 0.0, 0.0)}, "Pierna_Sup.R": {"rot": (-1.55, 0.0, 0.0)},
                "Pierna_Inf.L": {"rot": (1.55, 0.0, 0.0)}, "Pierna_Inf.R": {"rot": (1.55, 0.0, 0.0)},
                "Brazo_Sup.L": {"rot": (-0.35, 0.0, 0.0)}, "Brazo_Sup.R": {"rot": (-0.35, 0.0, 0.0)}},
}


def rig_activo(ctx):
    ob = ctx.active_object
    if ob is None:
        return None
    if ob.type != "ARMATURE" and ob.parent and ob.parent.type == "ARMATURE":
        ob = ob.parent
    if ob.type == "ARMATURE" and "Cara" in ob.pose.bones and "kit_chuy" in ob:
        return ob
    return None


def _key(pb, clave, frame, group):
    if clave:
        for path in ("location", "rotation_euler", "scale"):
            pb.keyframe_insert(path, frame=frame, group=group)


def aplicar(rig, nombre, clave=False, frame=None):
    data = EXPRESIONES[nombre]
    cara = rig.pose.bones["Cara"]
    props = data.get("p", {})
    for p in PROPS:
        if p in cara:
            cara[p] = float(props.get(p, 0.0))
            if clave:
                cara.keyframe_insert(f'["{p}"]', frame=frame, group="Cara")
    huesos = data.get("b", {})
    for n in HUESOS_CARA:
        pb = rig.pose.bones.get(n)
        if pb is None:
            continue
        t = huesos.get(n, {})
        lx, ly = t.get("loc", (0.0, 0.0))
        pb.location = (lx, ly, 0.0)
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0.0, 0.0, t.get("rot", 0.0))
        sx, sy = t.get("esc", (1.0, 1.0))
        pb.scale = (sx, sy, 1.0)
        _key(pb, clave, frame, n)
    rig.update_tag()


def pose(rig, nombre, clave=False, frame=None):
    data = POSES[nombre]
    raiz = rig.pose.bones["Raiz"]
    raiz["IK_Piernas"] = float(data.get("_ik", 1.0))
    if clave:
        raiz.keyframe_insert('["IK_Piernas"]', frame=frame, group="Raiz")
    for n in HUESOS_CUERPO:
        pb = rig.pose.bones.get(n)
        if pb is None:
            continue
        t = data.get(n, {})
        pb.location = t.get("loc", (0.0, 0.0, 0.0))
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = t.get("rot", (0.0, 0.0, 0.0))
        pb.scale = (1.0, 1.0, 1.0)
        _key(pb, clave, frame, n)
    rig.update_tag()


class KITCHUY_OT_expresion(bpy.types.Operator):
    """Aplica una expresión a la cara de Chuy"""
    bl_idname = "kitchuy.expresion"
    bl_label = "Expresión"
    bl_options = {"REGISTER", "UNDO"}
    nombre: StringProperty()

    def execute(self, ctx):
        rig = rig_activo(ctx)
        if rig is None:
            self.report({"WARNING"}, "Selecciona a ChuyMinesitoo")
            return {"CANCELLED"}
        aplicar(rig, self.nombre, ctx.scene.kitchuy_clave, ctx.scene.frame_current)
        return {"FINISHED"}


class KITCHUY_OT_pose(bpy.types.Operator):
    """Aplica una pose de cuerpo"""
    bl_idname = "kitchuy.pose"
    bl_label = "Pose"
    bl_options = {"REGISTER", "UNDO"}
    nombre: StringProperty()

    def execute(self, ctx):
        rig = rig_activo(ctx)
        if rig is None:
            return {"CANCELLED"}
        pose(rig, self.nombre, ctx.scene.kitchuy_clave, ctx.scene.frame_current)
        return {"FINISHED"}


class KITCHUY_OT_parpadeo(bpy.types.Operator):
    """Inserta un parpadeo completo desde el cuadro actual"""
    bl_idname = "kitchuy.parpadeo"
    bl_label = "Insertar parpadeo"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, ctx):
        rig = rig_activo(ctx)
        if rig is None:
            return {"CANCELLED"}
        cara = rig.pose.bones["Cara"]
        f = ctx.scene.frame_current
        base = {p: cara.get(p, 0.0) for p in ("Parpadeo_L", "Parpadeo_R")}
        for df, v in ((0, None), (2, 1.0), (3, 1.0), (5, None)):
            for p in base:
                cara[p] = base[p] if v is None else v
                cara.keyframe_insert(f'["{p}"]', frame=f + df, group="Cara")
        return {"FINISHED"}


class KITCHUY_PT_cara(bpy.types.Panel):
    bl_label = "Cara de Chuy"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Kit Chuy"

    @classmethod
    def poll(cls, ctx):
        return rig_activo(ctx) is not None

    def draw(self, ctx):
        rig = rig_activo(ctx)
        cara = rig.pose.bones["Cara"]
        L = self.layout
        L.prop(ctx.scene, "kitchuy_clave", text="Insertar clave al aplicar")
        g = L.grid_flow(columns=2, align=True)
        for n in EXPRESIONES:
            g.operator("kitchuy.expresion", text=n).nombre = n
        L.operator("kitchuy.parpadeo", icon="HIDE_ON")
        for titulo, lista in GRUPOS.items():
            box = L.box()
            box.label(text=titulo)
            col = box.column(align=True)
            for p in lista:
                if p in cara:
                    col.prop(cara, f'["{p}"]', text=p.replace("_", " "), slider=True)


class KITCHUY_PT_cuerpo(bpy.types.Panel):
    bl_label = "Poses de Chuy"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Kit Chuy"

    @classmethod
    def poll(cls, ctx):
        return rig_activo(ctx) is not None

    def draw(self, ctx):
        rig = rig_activo(ctx)
        L = self.layout
        L.prop(rig.pose.bones["Raiz"], '["IK_Piernas"]', text="Piernas IK (1) / FK (0)", slider=True)
        g = L.grid_flow(columns=2, align=True)
        for n in POSES:
            g.operator("kitchuy.pose", text=n).nombre = n


CLASES = (KITCHUY_OT_expresion, KITCHUY_OT_pose, KITCHUY_OT_parpadeo, KITCHUY_PT_cara, KITCHUY_PT_cuerpo)


def register():
    bpy.types.Scene.kitchuy_clave = BoolProperty(name="Clave automática", default=True)
    for c in CLASES:
        try:
            bpy.utils.register_class(c)
        except ValueError:
            pass


if __name__ == "__main__":
    register()
