# Kit Pueblo - Panel de caras
# Aparece en la Vista 3D > barra lateral (tecla N) > pestaña "Kit Pueblo".
# Si no aparece al abrir el archivo: Editor de Texto > este archivo > "Run Script".
import bpy
from bpy.props import StringProperty, BoolProperty

BOCA = ["Sonrisa", "Triste", "Abierta", "Risa", "Mueca", "Grito", "Nervioso", "Lengua"]
OJOS = ["Parpadeo_L", "Parpadeo_R", "Ojos_Felices"]
EXTRAS = ["Rubor", "Lagrimas", "Sudor"]
PROPS = BOCA + OJOS + EXTRAS

# Huesos de la cara que tocan las expresiones (se regresan a cero antes de aplicar una).
HUESOS = ["Mirada", "Ojo.L", "Ojo.R", "Pupila.L", "Pupila.R", "Parpado_Sup.L", "Parpado_Sup.R",
          "Parpado_Inf.L", "Parpado_Inf.R", "Ceja.L", "Ceja.R", "Boca"]

# Cada expresión: valores de propiedades + transformaciones de huesos.
# loc = (x, y) en el plano de la cara (metros), rot = giro en el plano (radianes), esc = escala (x, y)
EXPRESIONES = {
    "Neutral": {},
    "Feliz": {"p": {"Sonrisa": 1.0, "Ojos_Felices": 0.25},
              "b": {"Ceja.L": {"loc": (0, 0.008)}, "Ceja.R": {"loc": (0, 0.008)}}},
    "Muy feliz": {"p": {"Risa": 1.0, "Ojos_Felices": 1.0, "Rubor": 0.5},
                  "b": {"Ceja.L": {"loc": (0, 0.016)}, "Ceja.R": {"loc": (0, 0.016)}}},
    "Triste": {"p": {"Triste": 1.0},
               "b": {"Ceja.L": {"loc": (0, 0.006), "rot": -0.32}, "Ceja.R": {"loc": (0, 0.006), "rot": 0.32},
                     "Parpado_Sup.L": {"loc": (0, -0.018), "rot": -0.28},
                     "Parpado_Sup.R": {"loc": (0, -0.018), "rot": 0.28},
                     "Mirada": {"loc": (0, -0.012)}}},
    "Llorando": {"p": {"Triste": 0.7, "Abierta": 0.35, "Lagrimas": 1.0},
                 "b": {"Ceja.L": {"loc": (0, 0.01), "rot": -0.38}, "Ceja.R": {"loc": (0, 0.01), "rot": 0.38},
                       "Parpado_Sup.L": {"loc": (0, -0.025), "rot": -0.3},
                       "Parpado_Sup.R": {"loc": (0, -0.025), "rot": 0.3}}},
    "Enojado": {"p": {"Triste": 0.55},
                "b": {"Ceja.L": {"loc": (0, -0.012), "rot": 0.42}, "Ceja.R": {"loc": (0, -0.012), "rot": -0.42},
                      "Parpado_Sup.L": {"loc": (0, -0.022), "rot": 0.32},
                      "Parpado_Sup.R": {"loc": (0, -0.022), "rot": -0.32},
                      "Pupila.L": {"esc": (0.85, 0.85)}, "Pupila.R": {"esc": (0.85, 0.85)}}},
    "Furioso": {"p": {"Grito": 0.55, "Mueca": 0.45},
                "b": {"Ceja.L": {"loc": (0, -0.016), "rot": 0.55}, "Ceja.R": {"loc": (0, -0.016), "rot": -0.55},
                      "Parpado_Sup.L": {"loc": (0, -0.03), "rot": 0.4},
                      "Parpado_Sup.R": {"loc": (0, -0.03), "rot": -0.4},
                      "Pupila.L": {"esc": (0.7, 0.7)}, "Pupila.R": {"esc": (0.7, 0.7)}}},
    "Sorprendido": {"p": {"Abierta": 1.0},
                    "b": {"Ceja.L": {"loc": (0, 0.024)}, "Ceja.R": {"loc": (0, 0.024)},
                          "Ojo.L": {"esc": (1.08, 1.12)}, "Ojo.R": {"esc": (1.08, 1.12)},
                          "Pupila.L": {"esc": (0.75, 0.75)}, "Pupila.R": {"esc": (0.75, 0.75)}}},
    "Asustado": {"p": {"Grito": 0.45, "Nervioso": 0.55, "Sudor": 1.0},
                 "b": {"Ceja.L": {"loc": (0, 0.02), "rot": -0.3}, "Ceja.R": {"loc": (0, 0.02), "rot": 0.3},
                       "Ojo.L": {"esc": (1.1, 1.15)}, "Ojo.R": {"esc": (1.1, 1.15)},
                       "Pupila.L": {"esc": (0.55, 0.55)}, "Pupila.R": {"esc": (0.55, 0.55)}}},
    "Nervioso": {"p": {"Nervioso": 1.0, "Sudor": 1.0},
                 "b": {"Ceja.L": {"loc": (0, 0.01), "rot": -0.2}, "Ceja.R": {"loc": (0, 0.01), "rot": 0.2},
                       "Mirada": {"loc": (0.016, 0)}}},
    "Sospechoso": {"p": {"Parpadeo_L": 0.45, "Parpadeo_R": 0.45, "Sonrisa": 0.35},
                   "b": {"Ceja.L": {"loc": (0, -0.006), "rot": 0.15}, "Ceja.R": {"loc": (0, 0.012), "rot": 0.1},
                         "Mirada": {"loc": (0.018, 0)}, "Boca": {"loc": (0.01, 0), "rot": 0.18}}},
    "Malvado": {"p": {"Mueca": 1.0, "Ojos_Felices": 0.15},
                "b": {"Ceja.L": {"loc": (0, -0.01), "rot": 0.4}, "Ceja.R": {"loc": (0, -0.01), "rot": -0.4},
                      "Parpado_Sup.L": {"loc": (0, -0.02), "rot": 0.3},
                      "Parpado_Sup.R": {"loc": (0, -0.02), "rot": -0.3}}},
    "Dormido": {"p": {"Parpadeo_L": 1.0, "Parpadeo_R": 1.0, "Abierta": 0.2},
                "b": {"Ceja.L": {"loc": (0, -0.004)}, "Ceja.R": {"loc": (0, -0.004)}}},
    "Enamorado": {"p": {"Sonrisa": 0.85, "Ojos_Felices": 0.55, "Rubor": 1.0},
                  "b": {"Ceja.L": {"loc": (0, 0.012), "rot": -0.12}, "Ceja.R": {"loc": (0, 0.012), "rot": 0.12}}},
    "Guiño": {"p": {"Sonrisa": 0.7, "Lengua": 1.0, "Parpadeo_R": 1.0},
              "b": {"Ceja.L": {"loc": (0, 0.012)}, "Ceja.R": {"loc": (0, -0.006)}}},
}


def rig_activo(ctx):
    ob = ctx.active_object
    if ob is None:
        return None
    if ob.type != "ARMATURE" and ob.parent and ob.parent.type == "ARMATURE":
        ob = ob.parent
    if ob.type == "ARMATURE" and "Cara" in ob.pose.bones:
        return ob
    return None


def aplicar(rig, nombre, clave=False, frame=None):
    data = EXPRESIONES[nombre]
    cara = rig.pose.bones["Cara"]
    props = data.get("p", {})
    for p in PROPS:
        if p in cara:
            cara[p] = float(props.get(p, 0.0))
            if clave:
                cara.keyframe_insert(f'["{p}"]', frame=frame, group="Cara")
    huesos = data.get("b", {})
    for n in HUESOS:
        pb = rig.pose.bones.get(n)
        if pb is None:
            continue
        t = huesos.get(n, {})
        lx, ly = t.get("loc", (0.0, 0.0))
        pb.location = (lx, ly, 0.0)
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0.0, 0.0, t.get("rot", 0.0))
        sx, sy = t.get("esc", (1.0, 1.0))
        pb.scale = (sx, sy, 1.0)
        if clave:
            for path in ("location", "rotation_euler", "scale"):
                pb.keyframe_insert(path, frame=frame, group=n)
    rig.update_tag()


class KIT_OT_expresion(bpy.types.Operator):
    """Aplica una expresión a la cara del personaje activo"""
    bl_idname = "kit.expresion"
    bl_label = "Expresión"
    bl_options = {"REGISTER", "UNDO"}
    nombre: StringProperty()

    def execute(self, ctx):
        rig = rig_activo(ctx)
        if rig is None:
            self.report({"WARNING"}, "Selecciona un personaje del kit")
            return {"CANCELLED"}
        aplicar(rig, self.nombre, ctx.scene.kit_clave_auto, ctx.scene.frame_current)
        return {"FINISHED"}


class KIT_OT_parpadeo(bpy.types.Operator):
    """Inserta un parpadeo completo (abre-cierra-abre) desde el cuadro actual"""
    bl_idname = "kit.parpadeo"
    bl_label = "Insertar parpadeo"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, ctx):
        rig = rig_activo(ctx)
        if rig is None:
            return {"CANCELLED"}
        cara = rig.pose.bones["Cara"]
        f = ctx.scene.frame_current
        base = {p: cara.get(p, 0.0) for p in ("Parpadeo_L", "Parpadeo_R")}
        for df, v in ((0, None), (2, 1.0), (3, 1.0), (5, None)):
            for p in base:
                cara[p] = base[p] if v is None else v
                cara.keyframe_insert(f'["{p}"]', frame=f + df, group="Cara")
        return {"FINISHED"}


class KIT_PT_cara(bpy.types.Panel):
    bl_label = "Cara del personaje"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Kit Pueblo"

    @classmethod
    def poll(cls, ctx):
        return rig_activo(ctx) is not None

    def draw(self, ctx):
        rig = rig_activo(ctx)
        cara = rig.pose.bones["Cara"]
        L = self.layout
        L.label(text=rig.name.replace("_Rig", ""), icon="ARMATURE_DATA")
        L.prop(ctx.scene, "kit_clave_auto", text="Insertar clave al aplicar")
        g = L.grid_flow(columns=2, align=True)
        for n in EXPRESIONES:
            g.operator("kit.expresion", text=n).nombre = n
        L.operator("kit.parpadeo", icon="HIDE_ON")
        for titulo, lista in (("Boca", BOCA), ("Ojos", OJOS), ("Extras", EXTRAS)):
            box = L.box()
            box.label(text=titulo)
            col = box.column(align=True)
            for p in lista:
                if p in cara:
                    col.prop(cara, f'["{p}"]', text=p.replace("_", " "), slider=True)


CLASES = (KIT_OT_expresion, KIT_OT_parpadeo, KIT_PT_cara)


def register():
    bpy.types.Scene.kit_clave_auto = BoolProperty(name="Clave automática", default=True)
    for c in CLASES:
        try:
            bpy.utils.register_class(c)
        except ValueError:
            pass


if __name__ == "__main__":
    register()
