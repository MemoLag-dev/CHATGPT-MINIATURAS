"""Genera Kit_ChuyMinesitoo.blend a partir de avatares.blend (el archivo original solo se lee).

Uso:
  blender --background --factory-startup --python scripts/build_chuy.py -- [previews] [src=RUTA\\avatares.blend]
"""
import bpy, bmesh, sys, os, math, traceback
import numpy as np
from mathutils import Vector, Matrix

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
KIT = os.path.dirname(HERE)
ARGS = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
LOG = open(os.path.join(KIT, "build_log.txt"), "w", encoding="utf-8")


def log(*a):
    LOG.write(" ".join(str(x) for x in a) + "\n")
    LOG.flush()


from kit_lib import coll, lin, MB, flat, new_mat, node, M, mixc, sep, smooth, tidy
import kit_characters as KC
import chuy_ui as UI

SRC = r"C:\Users\dealb\Videos\Youtube\Chuy Mine\Claude\avatares.blend"
for a in ARGS:
    if a.startswith("src="):
        SRC = a[4:]
NAME = "ChuyMinesitoo"
S = 0.35                                   # 1 stud = 0.35 m (misma escala que el Kit Pueblo)
PUEBLO = os.path.join(os.path.dirname(KIT), "Kit_Pueblo", "Kit_Pueblo.blend")
PI = math.pi
FACE_ROT = KC.FACE_ROT

VG = {"LowerTorso": "Torso_Inf", "UpperTorso": "Torso_Sup", "Head": "Cabeza"}
for side, s in (("Left", "L"), ("Right", "R")):
    VG.update({f"{side}UpperArm": f"Brazo_Sup.{s}", f"{side}LowerArm": f"Brazo_Inf.{s}", f"{side}Hand": f"Mano.{s}",
               f"{side}UpperLeg": f"Pierna_Sup.{s}", f"{side}LowerLeg": f"Pierna_Inf.{s}", f"{side}Foot": f"Pie.{s}"})


# ------------------------------------------------------------------ 1. importar y limpiar
def import_character(scn):
    with bpy.data.libraries.load(SRC, link=False) as (src, dst):
        dst.collections = [NAME]
    c = dst.collections[0]
    scn.collection.children.link(c)
    c.name = "CH_" + NAME
    old = bpy.data.objects[NAME]
    old.data.pose_position = "REST"
    bpy.context.view_layer.update()
    t = old.matrix_world.translation.copy()
    T = Matrix.Scale(S, 4) @ Matrix.Translation((-t.x, -t.y, 0.0))
    joints = {b.name: T @ old.matrix_world @ b.head_local for b in old.data.bones}
    meshes = [o for o in c.objects if o.type == "MESH"]
    for ob in meshes:
        mw = ob.matrix_world.copy()
        for m in list(ob.modifiers):
            if m.type == "ARMATURE":
                ob.modifiers.remove(m)
        ob.parent = None
        ob.data.transform(T @ mw)
        ob.matrix_world = Matrix()
        for g in ob.vertex_groups:
            if g.name in VG:
                g.name = VG[g.name]
    arm = old.data
    bpy.data.objects.remove(old)
    bpy.data.armatures.remove(arm)
    body = bpy.data.objects[NAME + "_Cuerpo"]
    for ob in meshes:
        if "Gorrito" in ob.name:
            ob.name = NAME + "_Gorrito_Ajolote"
        elif "Gomis" in ob.name:
            ob.name = NAME + "_Gomitas"
    log("importado", [o.name for o in meshes])
    return c, body, meshes, joints


def vg_bbox(ob):
    res = {}
    names = {g.index: g.name for g in ob.vertex_groups}
    for v in ob.data.vertices:
        for g in v.groups:
            if g.weight > 0.5:
                n = names[g.group]
                lo, hi = res.setdefault(n, [Vector((1e9,) * 3), Vector((-1e9,) * 3)])
                res[n] = [Vector(map(min, lo, v.co)), Vector(map(max, hi, v.co))]
    return res


# ------------------------------------------------------------------ 2. medir la cara original en la textura
def face_anchors(body):
    me = body.data
    hi = next(i for i, m in enumerate(me.materials) if m and m.name.endswith("_Head"))
    mat = me.materials[hi]
    nt = mat.node_tree
    img = next(n.image for n in nt.nodes if n.type == "TEX_IMAGE")
    uvn = next((n for n in nt.nodes if n.type == "UVMAP"), None)
    uvname = uvn.uv_map if uvn is not None and uvn.uv_map else me.uv_layers.active.name
    w, h = img.size
    px = np.array(img.pixels[:], np.float32).reshape(h, w, 4)
    dark = (px[..., :3].mean(-1) < 0.35) & (px[..., 3] > 0.5)
    rows, cols = np.nonzero(dark)
    mid = (rows.max() + rows.min()) / 2
    up = rows > mid
    er, ec, mr, mc = rows[up], cols[up], rows[~up], cols[~up]
    cm = np.median(ec)
    eyes_uv = []
    for sel in (ec < cm, ec >= cm):
        r_, c_ = er[sel], ec[sel]
        eyes_uv.append(((c_.mean() + 0.5) / w, (r_.mean() + 0.5) / h, (c_.max() - c_.min() + 1) / 2, (r_.max() - r_.min() + 1) / 2))

    def col_center(cc):
        sel = np.abs(mc - cc) <= 2
        return (mr[sel].max() + mr[sel].min()) / 2 + 0.5, (mr[sel].max() - mr[sel].min() + 1)
    xl, xr = mc.min() + 4, mc.max() - 4
    xc = (mc.min() + mc.max()) / 2
    me.calc_loop_triangles()
    uvl = me.uv_layers[uvname].data
    tris = []
    for lt in me.loop_triangles:
        if lt.material_index == hi:
            tris.append((lt, [uvl[l].uv.copy() for l in lt.loops]))

    def uv3d(u, v):
        p = Vector((u, v))
        best = None
        for lt, (a, b, c) in tris:
            v0, v1, v2 = b - a, c - a, p - a
            d00, d01, d11 = v0.dot(v0), v0.dot(v1), v1.dot(v1)
            den = d00 * d11 - d01 * d01
            if abs(den) < 1e-16:
                continue
            d20, d21 = v2.dot(v0), v2.dot(v1)
            bv = (d11 * d20 - d01 * d21) / den
            bw = (d00 * d21 - d01 * d20) / den
            bu = 1 - bv - bw
            if bu >= -1e-5 and bv >= -1e-5 and bw >= -1e-5:
                co = [me.vertices[i].co for i in lt.vertices]
                pos = co[0] * bu + co[1] * bv + co[2] * bw
                if best is None or pos.y < best.y:
                    best = pos
        return best
    E = [uv3d(u, v) for u, v, _, _ in eyes_uv]
    order = sorted(range(2), key=lambda i: E[i].x)
    eR, eL = E[order[0]], E[order[1]]
    rad_px = np.mean([eyes_uv[i][2] for i in range(2)])
    du_px = abs(eyes_uv[0][0] - eyes_uv[1][0]) * w
    mpp = (eL - eR).length / du_px                    # metros por píxel de textura
    rl, _ = col_center(xl)
    rr, _ = col_center(xr)
    rc, thick = col_center(xc)
    pl, pr, pc = uv3d((xl + 0.5) / w, rl / h), uv3d((xr + 0.5) / w, rr / h), uv3d((xc + 0.5) / w, rc / h)
    f = dict(ex=(eL.x - eR.x) / 2, ez=(eL.z + eR.z) / 2, r=rad_px * mpp,
             W=(pr.x - pl.x) / 2 + 4 * mpp, TH=thick * mpp, SAG=(pl.z + pr.z) / 2 - pc.z, mzc=pc.z,
             front_y=min(eL.y, eR.y, pc.y))
    log("cara medida", {k: round(v, 4) for k, v in f.items()}, "eyes", tuple(eL), tuple(eR))
    # quitar la cara pintada de la textura (queda solo el color de piel)
    mix = next(n for n in nt.nodes if n.type == "MIX")
    fac = next(s for s in mix.inputs if s.identifier == "Factor_Float")
    for l in list(fac.links):
        nt.links.remove(l)
    fac.default_value = 0.0
    return f


# ------------------------------------------------------------------ utilidades de cara
def add_key(ob, name, fn):
    if ob.data.shape_keys is None:
        ob.shape_key_add(name="Basis")
    kb = ob.shape_key_add(name=name, from_mix=False)
    for i, v in enumerate(ob.data.vertices):
        x, y = fn(v.co.x, v.co.y)
        kb.data[i].co = (x, y, 0.0)
    return kb


def drv(owner, path, idx, rig, varmap, expr, bone="Cara"):
    fc = owner.driver_add(path, idx) if idx is not None else owner.driver_add(path)
    d = fc.driver
    d.type = "SCRIPTED"
    for vn, prop in varmap.items():
        v = d.variables.new()
        v.name, v.type = vn, "SINGLE_PROP"
        v.targets[0].id_type = "OBJECT"
        v.targets[0].id = rig
        v.targets[0].data_path = f'pose.bones["{bone}"]["{prop}"]'
    d.expression = expr
    return fc


def drv_scale(ob, rig, varmap, expr, exprs=None):
    for i in range(3):
        drv(ob, "scale", i, rig, varmap, exprs[i] if exprs else expr)


def poly_mesh(name, polys, rings=2):
    """Varios polígonos rellenos (abanico desde el centro con anillos) en una sola malla."""
    bm = bmesh.new()
    for pts in polys:
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        c = bm.verts.new((cx, cy, 0))
        R = [[bm.verts.new((cx + (p[0] - cx) * k / rings, cy + (p[1] - cy) * k / rings, 0)) for p in pts]
             for k in range(1, rings + 1)]
        n = len(pts)
        for i in range(n):
            bm.faces.new((c, R[0][i], R[0][(i + 1) % n]))
        for a, b in zip(R[:-1], R[1:]):
            for i in range(n):
                bm.faces.new((a[i], b[i], b[(i + 1) % n], a[(i + 1) % n]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    uv = bm.loops.layers.uv.new("UVMap")
    for fc in bm.faces:
        for l in fc.loops:
            l[uv].uv = (l.vert.co.x, l.vert.co.y)
    me = KC.mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def ribbon_mesh(name, pts, width):
    bm = bmesh.new()
    L, Rr = [], []
    n = len(pts)
    for i, p in enumerate(pts):
        a = Vector(pts[max(i - 1, 0)])
        b = Vector(pts[min(i + 1, n - 1)])
        t = (b - a).normalized()
        nrm = Vector((-t.y, t.x))
        w = width * (0.6 + 0.4 * min(1.0, i / 4.0)) if i < 4 else width
        L.append(bm.verts.new((p[0] + nrm.x * w / 2, p[1] + nrm.y * w / 2, 0)))
        Rr.append(bm.verts.new((p[0] - nrm.x * w / 2, p[1] - nrm.y * w / 2, 0)))
    for i in range(n - 1):
        bm.faces.new((L[i], Rr[i], Rr[i + 1], L[i + 1]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = KC.mesh_from_bm(bm, name)
    me.shade_smooth()
    return me


def rect_pts(cx, cy, L, T, ang, n=3):
    """Rectángulo redondeado (cápsula) rotado."""
    pts = []
    ca, sa = math.cos(ang), math.sin(ang)
    for side in (0, 1):
        for i in range(n + 1):
            a = PI / 2 + PI * i / n + (PI if side else 0)
            x = (-1 if side == 0 else 1) * (L / 2 - T / 2) + T / 2 * math.cos(a)
            y = T / 2 * math.sin(a)
            pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return pts


def heart_pts(h, n=40):
    raw = []
    for i in range(n):
        t = 2 * PI * i / n
        raw.append((16 * math.sin(t) ** 3, 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)))
    k = h / 30.0
    return [(x * k, (y + 2) * k) for x, y in raw]


def star_pts(R, n=5):
    return [((R if i % 2 == 0 else R * 0.45) * math.sin(PI * i / n), (R if i % 2 == 0 else R * 0.45) * math.cos(PI * i / n))
            for i in range(2 * n)]


def arc_pts(cx, cy, R, T, a0, a1, n=8):
    outer = [(cx + (R + T / 2) * math.cos(a0 + (a1 - a0) * i / n), cy + (R + T / 2) * math.sin(a0 + (a1 - a0) * i / n)) for i in range(n + 1)]
    inner = [(cx + (R - T / 2) * math.cos(a1 - (a1 - a0) * i / n), cy + (R - T / 2) * math.sin(a1 - (a1 - a0) * i / n)) for i in range(n + 1)]
    return outer + inner


def flatm(name, hexcol, rough=0.5, emit=0.0):
    m = flat(name, hexcol, rough, emit=emit)
    return m


def mat_stream(name):
    m, nt, b = new_mat(name, 0.1)
    uvn = node(nt, "ShaderNodeUVMap")
    u, v, _ = sep(nt, uvn.outputs["UV"])
    hl = M(nt, "LESS_THAN", M(nt, "ABSOLUTE", M(nt, "SUBTRACT", u, -0.0012)), 0.0009)
    nt.links.new(mixc(nt, hl, lin("#8fd0ff"), lin("#ffffff")), b.inputs["Base Color"])
    b.inputs["Emission Color"].default_value = lin("#bfe6ff")
    b.inputs["Emission Strength"].default_value = 0.15
    m.diffuse_color = lin("#8fd0ff")
    tidy(nt)
    return m


# ------------------------------------------------------------------ boca de Chuy
def _cap(s):
    return max(0.0, 1.0 - s ** 6) ** 0.5


def _e(s, p=0.5):
    return max(0.0, 1.0 - s * s) ** p


def mouth_fn(P):
    W, TH, SAG = P["W"], P["TH"], P["SAG"]

    def shape(key, s):
        h = TH / 2 * _cap(s)
        if key == "Sonrisa":
            xs, c = W * 1.35, SAG * 1.9 * (s * s - 0.55)
        elif key == "Triste":
            xs, c = W * 1.05, -SAG * 1.5 * (s * s - 0.5)
        elif key == "Plana":
            xs, c = W, 0.0
        elif key == "Abierta":
            e = _e(s, 0.42)
            U, L = (0.55 * W + TH / 2) * e, -(0.75 * W + TH / 2) * e
            return W * 0.55 * s, U, L, (U + L) / 2
        elif key == "Risa":
            U = SAG * 0.5 * s * s + h
            L = U - (1.25 * W * _e(s, 0.75) + TH * _cap(s))
            return W * 1.4 * s, U, L, (U + L) / 2
        elif key == "Mueca":
            c = SAG * 1.5 * (s * s - 0.4)
            hh = 0.38 * W * _e(s) + h
            return W * 1.6 * s, c + hh, c - hh, c
        elif key == "Grito":
            e = _e(s, 0.6)
            U, L = (0.5 * W + TH / 2) * e, -(1.55 * W + TH / 2) * e
            return W * 0.95 * s, U, L, (U + L) / 2
        elif key == "Nervioso":
            xs, c = W * 1.2, 0.14 * W * math.sin(3.2 * PI * s)
        elif key == "Lengua":
            xs, c = W * 1.1, SAG * 0.8 * (s * s - 0.5)
        elif key == "Gato":
            xs, c = W * 0.85, 0.18 * W * math.cos(2 * PI * s)
        elif key == "Puchero":
            e = _e(s, 0.45)
            U, L = (0.22 * W + TH / 2) * e, -(0.22 * W + TH / 2) * e
            return W * 0.3 * s, U, L, 0.0
        else:
            xs, c = W, SAG * (s * s - 0.6)
        return xs * s, c + h, c - h, c

    def teeth_up(key, s):
        f = {"Risa": 0.86, "Mueca": 0.93, "Grito": 0.7}.get(key, 0.9)
        x, U, L, c = shape(key, f * s)
        if key == "Risa":
            top = U - 0.25 * TH
            return x, top, max(top - 0.32 * W * _e(s, 0.35), L + 0.3 * TH)
        if key == "Mueca":
            top = U - 0.25 * TH
            return x, top, min(c + 0.12 * TH, top)
        if key == "Grito":
            top = U - 0.2 * TH
            return x, top, top - 0.25 * W * _e(s)
        return x, c, c

    def teeth_down(key, s):
        f = {"Mueca": 0.93, "Grito": 0.6}.get(key, 0.9)
        x, U, L, c = shape(key, f * s)
        if key == "Mueca":
            top = c - 0.12 * TH
            return x, top, min(L + 0.25 * TH, top)
        if key == "Grito":
            bot = L + 0.2 * TH
            return x, bot + 0.2 * W * _e(s), bot
        return x, c, c

    def tongue(key, s):
        f = {"Risa": 0.5, "Abierta": 0.6, "Grito": 0.5, "Lengua": 0.42}.get(key, 0.5)
        x, U, L, c = shape(key, f * s)
        if key in ("Risa", "Abierta", "Grito"):
            hg = {"Risa": 0.42, "Abierta": 0.4, "Grito": 0.62}[key] * W
            bot = L + 0.25 * TH
            top = bot + hg * _e(s)
            if key == "Risa":
                top = min(top, U - 0.35 * W)
            return x, max(top, bot), bot
        if key == "Lengua":
            return x, c, c - 0.8 * W * _e(s)
        return x, c, c
    return shape, teeth_up, teeth_down, tongue


def strip(name, fn, c, nx=40, ny=3):
    ss = [-1 + 2 * i / nx for i in range(nx + 1)]

    def verts(key):
        out = []
        for j in range(ny + 1):
            for s in ss:
                x, top, bot = fn(key, s)[:3]
                out.append((x, bot + (top - bot) * j / ny, 0.0))
        return out
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    V = [bm.verts.new(co) for co in verts("Basis")]
    idx = {v: i for i, v in enumerate(V)}
    for j in range(ny):
        for i in range(nx):
            a = j * (nx + 1) + i
            fc = bm.faces.new((V[a], V[a + 1], V[a + nx + 2], V[a + nx + 1]))
            for l in fc.loops:
                k = idx[l.vert]
                l[uv].uv = ((k % (nx + 1)) / nx, (k // (nx + 1)) / ny)
    me = KC.mesh_from_bm(bm, name)
    me.shade_smooth()
    ob = bpy.data.objects.new(name, me)
    c.objects.link(ob)
    ob.shape_key_add(name="Basis")
    for k in UI.BOCA:
        kb = ob.shape_key_add(name=k, from_mix=False)
        for i, co in enumerate(verts(k)):
            kb.data[i].co = co
    return ob


# ------------------------------------------------------------------ 3. rig nuevo
def build_rig(c, body, accessories, joints, F):
    bb = vg_bbox(body)
    data = bpy.data.armatures.new(NAME + "_Rig")
    rig = bpy.data.objects.new(NAME + "_Rig", data)
    c.objects.link(rig)
    rig.show_in_front = True
    rig["kit_chuy"] = 1
    vl = bpy.context.view_layer
    vl.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    eb = data.edit_bones
    cols = {n: data.collections.new(n) for n in ("Cuerpo", "IK", "Cara", "Mecanismo")}

    def B(n, h, t, parent=None, col="Cuerpo", deform=False):
        b = eb.new(n)
        b.head, b.tail, b.roll = Vector(h), Vector(t), 0.0
        b.parent = eb.get(parent) if parent else None
        b.use_deform = deform
        cols[col].assign(b)
        return b

    J = joints
    hips, waist, neck = J["LowerTorso"], J["UpperTorso"], J["Head"]
    top = bb["Cabeza"][1].z
    B("Raiz", (0, 0, 0), (0, 0.45, 0))
    B("Cadera", hips, hips + Vector((0, 0, 0.12)), "Raiz")
    B("Torso_Inf", hips, waist, "Cadera", deform=True)
    B("Torso_Sup", waist, neck, "Torso_Inf", deform=True)
    B("Cabeza", neck, (neck.x, neck.y, top), "Torso_Sup", deform=True)
    for side, s in (("Left", "L"), ("Right", "R")):
        sh, el, wr = J[f"{side}UpperArm"], J[f"{side}LowerArm"], J[f"{side}Hand"]
        B(f"Brazo_Sup.{s}", sh, el, "Torso_Sup", deform=True)
        B(f"Brazo_Inf.{s}", el, wr, f"Brazo_Sup.{s}", deform=True)
        hand_end = Vector((wr.x, wr.y, bb[f"Mano.{s}"][0].z + 0.02))
        B(f"Mano.{s}", wr, hand_end, f"Brazo_Inf.{s}", deform=True)
        hp, kn, an = J[f"{side}UpperLeg"], J[f"{side}LowerLeg"], J[f"{side}Foot"]
        toe = Vector((an.x, bb[f"Pie.{s}"][0].y + 0.03, 0.03))
        B(f"Pierna_Sup.{s}", hp, kn, "Torso_Inf", deform=True)
        B(f"Pierna_Inf.{s}", kn, an, f"Pierna_Sup.{s}", deform=True)
        B(f"Pie.{s}", an, toe, f"Pierna_Inf.{s}", deform=True)
        # control del pie alineado al mundo (X lado, Y frente/atrás, Z arriba)
        B(f"Pie_IK.{s}", an, an + Vector((0, 0.18, 0)), "Raiz", col="IK")
        B(f"MCH_Pie.{s}", an, toe, f"Pie_IK.{s}", col="Mecanismo")
        B(f"Rodilla.{s}", kn + Vector((0, -0.55, 0)), kn + Vector((0, -0.45, 0)), "Raiz", col="IK")
    up = Vector((0, 0, 0.02))
    by = F["front_y"] - 0.03

    def FB(n, x, z, parent, col="Cara", y=by):
        p = Vector((x, y, z))
        return B(n, p, p + up, parent, col)
    ex, ez = F["ex"], F["ez"]
    FB("Cara", 0.32, ez + 0.06, "Cabeza", y=0.0)
    FB("Mirada", 0.0, ez, "Cabeza", y=by - 0.1)
    for sx, s in ((1, "L"), (-1, "R")):
        FB("Ojo." + s, sx * ex, ez, "Cabeza")
        FB("Pupila." + s, sx * ex, ez, "Ojo." + s)
        FB("Ceja." + s, sx * ex, F["bz"], "Cabeza")
    FB("Boca", 0.0, F["mz"], "Cabeza")
    bpy.ops.object.mode_set(mode="OBJECT")
    cols["Mecanismo"].is_visible = False

    W = KC.widgets()
    pbs = rig.pose.bones
    for pb in pbs:
        pb.rotation_mode = "XYZ"

    def shape(n, w, sc, tr=(0, 0, 0), color="THEME01"):
        pb = pbs[n]
        pb.custom_shape = W[w]
        pb.use_custom_shape_bone_size = False
        pb.custom_shape_scale_xyz = sc if isinstance(sc, tuple) else (sc,) * 3
        pb.custom_shape_translation = tr
        pb.color.palette = color
    shape("Raiz", "root", 0.6, color="THEME03")
    shape("Cadera", "ring", 0.42, color="THEME04")
    shape("Torso_Inf", "ring", 0.36, (0, 0.05, 0), "THEME04")
    shape("Torso_Sup", "ring", 0.4, (0, 0.25, 0), "THEME04")
    shape("Cabeza", "ring", 0.3, (0, 0.08, 0), "THEME04")
    for s in ("L", "R"):
        for n, sc in (("Brazo_Sup", 0.12), ("Brazo_Inf", 0.1), ("Mano", 0.09), ("Pierna_Sup", 0.13), ("Pierna_Inf", 0.12)):
            shape(f"{n}.{s}", "ring", sc, (0, 0.05, 0), "THEME04")
        shape("Pie." + s, "ring", 0.06, (0, 0.05, 0), "THEME04")
        shape("Pie_IK." + s, "box", (0.11, 0.17, 0.11), (0, -0.07, -0.1), "THEME01")
        shape("Rodilla." + s, "circle", 0.04, color="THEME01")
        shape("Ojo." + s, "circle", F["a_big"] + F["t"] + 0.006, (0, 0, 0.02), "THEME09")
        shape("Pupila." + s, "circle", F["r"] * 1.3, (0, 0, 0.03), "THEME02")
        shape("Ceja." + s, "brow", F["bl"] / 2 + 0.004, (0, 0, 0.03), "THEME09")
    shape("Boca", "mouth", F["W"] * 1.6, (0, 0, 0.03), "THEME09")
    shape("Mirada", "look", F["ex"] * 0.75, color="THEME02")
    shape("Cara", "face", 0.06, color="THEME09")
    # deformación
    for ob in [body] + accessories:
        m = ob.modifiers.new("Rig", "ARMATURE")
        m.object = rig
        ob.parent = rig
    # IK de piernas con interruptor
    raiz = pbs["Raiz"]
    raiz["IK_Piernas"] = 1.0
    raiz.id_properties_ui("IK_Piernas").update(min=0.0, max=1.0, soft_min=0.0, soft_max=1.0, default=1.0)
    for s in ("L", "R"):
        ik = pbs["Pierna_Inf." + s].constraints.new("IK")
        ik.target, ik.subtarget = rig, "Pie_IK." + s
        ik.pole_target, ik.pole_subtarget = rig, "Rodilla." + s
        ik.pole_angle = -PI / 2
        ik.chain_count = 2
        cr = pbs["Pie." + s].constraints.new("COPY_ROTATION")
        cr.target, cr.subtarget = rig, "MCH_Pie." + s
        for con in (ik, cr):
            drv(con, "influence", None, rig, {"v": "IK_Piernas"}, "v", bone="Raiz")
    # cara: bloqueos y propiedades
    for pb in pbs:
        if pb.bone.collections and pb.bone.collections[0].name == "Cara":
            pb.lock_location[2] = True
            pb.lock_rotation[0] = pb.lock_rotation[1] = True
            pb.lock_scale[2] = True
    for n in ("Cara", "Mirada"):
        pbs[n].lock_rotation = (True, True, True)
        pbs[n].lock_scale = (True, True, True)
    pbs["Cara"].lock_location = (True, True, True)
    cara = pbs["Cara"]
    for p in UI.PROPS:
        cara[p] = 0.0
        cara.id_properties_ui(p).update(min=0.0, max=1.0, soft_min=0.0, soft_max=1.0, default=0.0)
        try:
            cara.property_overridable_library_set(f'["{p}"]', True)
        except Exception:
            pass
    for s in ("L", "R"):
        pb = pbs["Pupila." + s]
        cl = pb.constraints.new("COPY_LOCATION")
        cl.target, cl.subtarget = rig, "Mirada"
        cl.use_offset = True
        cl.target_space = cl.owner_space = "LOCAL"
        cl.use_z = False
        lim = pb.constraints.new("LIMIT_LOCATION")
        lim.owner_space = "LOCAL"
        for ax, v in (("x", (F["a_big"] - F["r"]) * 0.95), ("y", (F["b_big"] - F["r"]) * 0.95)):
            setattr(lim, "use_min_" + ax, True)
            setattr(lim, "use_max_" + ax, True)
            setattr(lim, "min_" + ax, -v)
            setattr(lim, "max_" + ax, v)
    return rig


# ------------------------------------------------------------------ 4. cara nueva
def build_face(c, rig, body, F):
    r, ex, ez = F["r"], F["ex"], F["ez"]
    FY = F["front_y"] - 0.004
    parts = []

    def put(me, name, mats, x, z, bone, off):
        for m in mats:
            me.materials.append(m)
        ob = bpy.data.objects.new(f"{NAME}_{name}", me)
        c.objects.link(ob)
        ob.matrix_world = Matrix.Translation((x, FY, z)) @ FACE_ROT
        KC.parent_to(ob, rig, bone)
        KC.shrink(ob, body, off)
        ob.visible_shadow = False
        parts.append(ob)
        return ob
    black = flatm("Chuy_Negro_Cara", "#141416", 0.45)
    white = flatm("Chuy_Brillo", "#ffffff", 0.3, emit=0.6)
    specials = {"C": "Corazones", "St": "Estrellas", "Sp": "Espirales", "X": "Ojos_X"}
    hide_dot = "max(0.0, 1.0-C-St-Sp-X)"
    th_line = max(0.0032, 0.5 * r)
    for sx, s in ((1, "L"), (-1, "R")):
        side_p = "Parpadeo_" + s
        # ojo de puntito (como el avatar original) con formas
        dot = put(KC.disc_mesh(f"{NAME}_Ojo.{s}", r, r * 1.08, 6, 48), f"Ojo.{s}", [black], sx * ex, ez, "Pupila." + s, 0.0026)
        ry = r * 1.08
        add_key(dot, "Cerrado", lambda x, y: (x * 1.3, (y / ry) * th_line / 2 - 0.1 * r))
        add_key(dot, "Feliz", lambda x, y: (x * 1.35, 0.95 * r * (1 - (x / r) ** 2) + (y / ry) * th_line / 2 - 0.35 * r))
        add_key(dot, "Triste", lambda x, y, sx=sx: (x, y * (0.3 + 0.7 * (1 - sx * x / r) / 2) if y > 0 else y))
        add_key(dot, "Enojado", lambda x, y, sx=sx: (x, y * (0.3 + 0.7 * (1 + sx * x / r) / 2) if y > 0 else y))
        add_key(dot, "Entrecerrado", lambda x, y: (x * 1.08, y * 0.3 if y > 0 else y * 0.85))
        kbs = dot.data.shape_keys.key_blocks
        for k, p in (("Cerrado", side_p), ("Feliz", "Ojos_Felices"), ("Triste", "Ojos_Tristes"),
                     ("Enojado", "Ojos_Enojados"), ("Entrecerrado", "Ojos_Entrecerrados")):
            drv(kbs[k], "value", None, rig, {"v": p}, "v")
        drv_scale(dot, rig, specials, hide_dot)
        # brillo
        br = put(KC.disc_mesh(f"{NAME}_Brillo.{s}", 0.33 * r, 0.33 * r, 2, 20), f"Brillo.{s}", [white],
                 sx * ex + 0.33 * r, ez + 0.4 * r, "Pupila." + s, 0.0036)
        drv_scale(br, rig, dict(specials, B="Brillo", P=side_p, Fe="Ojos_Felices", E="Ojos_Entrecerrados"),
                  "B*max(0.0, 1.0-P-Fe-C-St-Sp-X-0.5*E)")
        # modo ojos grandes: ojo blanco con contorno detrás del puntito
        a, b, t = F["a_big"], F["b_big"], F["t"]
        wh = put(KC.disc_mesh(f"{NAME}_OjoGrande.{s}", a + t, b + t, 5, 48), f"OjoGrande.{s}",
                 [KC.mat_eye("Chuy_OjoGrande", a, b)], sx * ex, ez, "Ojo." + s, 0.0015)
        g = dict(specials, G="Ojos_Grandes", P=side_p)
        drv_scale(wh, rig, g, None, ["max(0.0001, G*(1.0-C-St-Sp-X))", "max(0.0001, G*max(0.0, 1.0-P)*(1.0-C-St-Sp-X))", "max(0.0001, G)"])
        # ojos especiales
        for prop, me, mat, off in (
                ("Corazones", poly_mesh(f"{NAME}_Corazon.{s}", [heart_pts(3.2 * r)]), flatm("Chuy_Corazon", "#ff3d6e", 0.4, 0.3), 0.003),
                ("Estrellas", poly_mesh(f"{NAME}_Estrella.{s}", [star_pts(1.75 * r)]), flatm("Chuy_Estrella", "#ffd43b", 0.4, 0.4), 0.003),
                ("Espirales", ribbon_mesh(f"{NAME}_Espiral.{s}",
                                          [((0.12 + 1.45 * i / 60) * r * math.cos(sx * 2 * PI * 2.4 * i / 60),
                                            (0.12 + 1.45 * i / 60) * r * math.sin(sx * 2 * PI * 2.4 * i / 60)) for i in range(61)],
                                          0.34 * r), black, 0.003),
                ("Ojos_X", poly_mesh(f"{NAME}_OjoX.{s}", [rect_pts(0, 0, 2.7 * r, 0.6 * r, PI / 4), rect_pts(0, 0, 2.7 * r, 0.6 * r, -PI / 4)]),
                 black, 0.003)):
            ob = put(me, f"{prop}.{s}", [mat], sx * ex, ez, "Ojo." + s, off)
            drv_scale(ob, rig, {"v": prop}, "v")
            if prop == "Corazones":
                hb = put(KC.disc_mesh(f"{NAME}_BrilloCorazon.{s}", 0.3 * r, 0.24 * r, 2, 16), f"BrilloCorazon.{s}", [white],
                         sx * ex - 0.75 * r, ez + 0.75 * r, "Ojo." + s, 0.004)
                drv_scale(hb, rig, {"v": prop}, "v")
        # ceja (aparece con la propiedad "Cejas")
        brow = put(poly_mesh(f"{NAME}_Ceja.{s}", [rect_pts(0, 0, F["bl"], F["bt"], 0.0, 6)]), f"Ceja.{s}", [black],
                   sx * ex, F["bz"], "Ceja." + s, 0.0045)
        drv_scale(brow, rig, {"v": "Cejas"}, "v")
        # rubor, rayitas de pena, lágrima y chorro de llanto
        rub = put(KC.disc_mesh(f"{NAME}_Rubor.{s}", 2.4 * r, 1.35 * r, 3, 24), f"Rubor.{s}",
                  [KC.mat_soft("Chuy_Rubor", "#ff7d98", 2.4 * r, 1.35 * r, 0.6)], sx * (ex + 1.9 * r), ez - 2.7 * r, "Cabeza", 0.0008)
        drv_scale(rub, rig, {"v": "Rubor"}, "v")
        pena = put(poly_mesh(f"{NAME}_Pena.{s}", [rect_pts(i * 0.9 * r, 0, 1.5 * r, 0.32 * r, 1.1) for i in (-1, 0, 1)]),
                   f"Pena.{s}", [flatm("Chuy_Pena", "#e24f68", 0.5)], sx * (ex + 1.9 * r), ez - 2.7 * r, "Cabeza", 0.0013)
        drv_scale(pena, rig, {"v": "Pena"}, "v")
        tear = put(KC.fan_mesh(f"{NAME}_Lagrima.{s}", KC.drop_pts(0.85 * r, 2.2 * r)), f"Lagrima.{s}",
                   [KC.mat_drop("Chuy_Gota")], sx * (ex + 1.0 * r), ez - 2.0 * r, "Ojo." + s, 0.005)
        drv_scale(tear, rig, {"v": "Lagrimas"}, "v")
        L = max(0.03, ez - F["mz"] + 3.5 * r)
        wl = 1.1 * r
        stream_me = KC.grid_mesh(f"{NAME}_Llanto.{s}", [-wl / 2, 0.0, wl / 2], [-L * j / 10 for j in range(10, -1, -1)],
                                 lambda x, y: (x, y))
        st = put(stream_me, f"Llanto.{s}", [mat_stream("Chuy_Llanto")], sx * (ex + 0.15 * r), ez - 0.9 * r, "Ojo." + s, 0.0042)
        drv_scale(st, rig, {"v": "Llanto"}, None, ["min(1.0, v*4.0)", "max(0.0001, v)", "1.0"])
    # sudor, venita, líneas de susto (en la frente)
    sw = put(KC.fan_mesh(f"{NAME}_Sudor", KC.drop_pts(1.1 * r, 2.8 * r)), "Sudor", [KC.mat_drop("Chuy_Gota")],
             ex + 3.6 * r, ez + 2.6 * r, "Cabeza", 0.005)
    drv_scale(sw, rig, {"v": "Sudor"}, "v")
    rv = 0.75 * r
    ven = []
    for qx, qy in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
        ang = math.atan2(-qy, -qx)
        ven.append(arc_pts(qx * 1.25 * rv, qy * 1.25 * rv, rv, 0.55 * rv, ang - 0.65, ang + 0.65))
    vn = put(poly_mesh(f"{NAME}_Venita", ven), "Venita", [flatm("Chuy_Venita", "#e3343e", 0.5, 0.2)],
             -(ex + 2.6 * r), ez + 3.2 * r, "Cabeza", 0.004)
    drv_scale(vn, rig, {"v": "Venita"}, "v")
    lines = [rect_pts(x * r, 0, 3.0 * r, 0.42 * r, PI / 2) for x in (-2.4, -0.8, 0.8, 2.4)]
    ls = put(poly_mesh(f"{NAME}_LineasShock", lines), "LineasShock", [flatm("Chuy_Shock", "#4a4fb3", 0.6)],
             0.0, ez + 3.6 * r, "Cabeza", 0.0012)
    drv_scale(ls, rig, {"v": "Lineas_Shock"}, "v")
    # boca
    shape, tu, td, tg = mouth_fn(F)
    mouth_parts = [("Boca", shape, flatm("Chuy_Boca", "#1a1214", 0.5), 0.0016, 40, 3),
                   ("Lengua", tg, KC.mat_tongue("Chuy_Lengua"), 0.0022, 24, 3),
                   ("DientesSup", tu, KC.mat_teeth("Chuy_Dientes"), 0.0029, 24, 2),
                   ("DientesInf", td, KC.mat_teeth("Chuy_Dientes"), 0.0029, 24, 2)]
    for n, fn, mat, off, nx, ny in mouth_parts:
        ob = strip(f"{NAME}_{n}", fn, c, nx, ny)
        ob.data.materials.append(mat)
        ob.matrix_world = Matrix.Translation((0.0, FY, F["mz"])) @ FACE_ROT
        KC.parent_to(ob, rig, "Boca")
        KC.shrink(ob, body, off)
        ob.visible_shadow = False
        for k in UI.BOCA:
            drv(ob.data.shape_keys.key_blocks[k], "value", None, rig, {"v": k}, "v")
        parts.append(ob)
    log("piezas de cara", len(parts))
    return parts


# ------------------------------------------------------------------ escenas
def setup_render(scn, w=1080, h=1920):
    scn.render.engine = "BLENDER_EEVEE"
    scn.render.resolution_x, scn.render.resolution_y = w, h
    scn.render.resolution_percentage = 100
    scn.render.fps = 30
    scn.frame_start, scn.frame_end = 1, 300
    for k, v in (("taa_render_samples", 64), ("use_raytracing", True), ("use_shadows", True), ("use_fast_gi", True)):
        try:
            setattr(scn.eevee, k, v)
        except Exception:
            pass
    try:
        scn.view_settings.view_transform = "AgX"
        scn.view_settings.look = "AgX - Medium High Contrast"
    except Exception:
        pass
    scn["noche"] = 0.0


def camera(c, name, loc, target, lens):
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    cd.clip_start, cd.clip_end = 0.05, 1500
    ob = bpy.data.objects.new(name, cd)
    ob.location = loc
    ob.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
    c.objects.link(ob)
    return ob


def studio(scn, F):
    w = bpy.data.worlds.new("Estudio_Chuy")
    w.use_nodes = True
    bg = w.node_tree.nodes["Background"]
    bg.inputs["Color"].default_value = lin("#e3e8f0")
    bg.inputs["Strength"].default_value = 0.9
    scn.world = w
    st = coll("Estudio_Chuy", scene=scn)
    mb = MB()
    mb.box((0, 3, -0.05), (30, 20, 0.1), flat("Piso_Estudio_Chuy", "#eef1f5", 0.7))
    mb.box((0, 5, 4), (30, 0.2, 8), flat("Fondo_Estudio_Chuy", "#f6d6e2", 0.8))
    mb.obj("Estudio_Chuy_Piso", st)
    L = bpy.data.lights.new("Sol_Chuy", "SUN")
    L.energy = 3.0
    L.angle = 0.05
    so = bpy.data.objects.new("Sol_Chuy", L)
    so.rotation_euler = (math.radians(50), 0, math.radians(25))
    st.objects.link(so)
    cam = camera(st, "Cam_Cuerpo", (0.9, -4.2, 1.15), (0, 0, 0.92), 40)
    camera(st, "Cam_Cara", (0.0, -0.75, F["ez"] - 0.015), (0.0, 0.0, F["ez"] - 0.025), 85)
    camera(st, "Cam_Tres_Cuartos", (1.6, -3.3, 1.35), (0, 0, 0.95), 40)
    scn.camera = cam


def town_scene(c_char):
    if not os.path.exists(PUEBLO):
        log("sin Kit_Pueblo, se omite la escena del pueblo")
        return None
    scn = bpy.data.scenes.new("Chuy_en_el_Pueblo")
    setup_render(scn)
    with bpy.data.libraries.load(PUEBLO, link=True, relative=True) as (src, dst):
        dst.collections = ["SET_Pueblo", "Luces_Dia"]
        dst.worlds = ["Cielo_Dia"]
    town, luces = dst.collections
    scn.world = dst.worlds[0]
    scn.collection.children.link(luces)
    scn.collection.children.link(c_char)
    e = bpy.data.objects.new("Pueblo_Instancia", None)
    e.instance_type = "COLLECTION"
    e.instance_collection = town
    e.location = (0.0, 7.0, -0.12)
    scn.collection.objects.link(e)
    cc = coll("Camaras_Chuy_Pueblo", scn.collection)
    scn.camera = camera(cc, "Cam_Pueblo", (0.7, -3.4, 1.25), (0.0, 0.0, 1.05), 30)
    return scn


# ------------------------------------------------------------------ principal
def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scn = bpy.context.scene
    scn.name = NAME
    setup_render(scn)
    c, body, meshes, joints = import_character(scn)
    F = face_anchors(body)
    r = F["r"]
    F["t"] = max(0.003, 0.32 * r)
    F["a_big"] = min(2.7 * r, F["ex"] - F["t"] - 0.004)
    F["b_big"] = F["a_big"] * 1.22
    F["bl"], F["bt"] = 3.4 * r, 0.7 * r
    F["bz"] = F["ez"] + F["b_big"] + F["t"] + 1.1 * r
    F["mz"] = F["mzc"] + 0.6 * F["SAG"]
    log("cara final", {k: round(v, 4) for k, v in F.items()})
    acc = [o for o in meshes if o is not body]
    rig = build_rig(c, body, acc, joints, F)
    bpy.context.view_layer.update()
    build_face(c, rig, body, F)
    studio(scn, F)
    town = town_scene(c)
    txt = bpy.data.texts.new("kit_chuy_ui.py")
    txt.from_string(open(os.path.join(HERE, "chuy_ui.py"), encoding="utf-8").read())
    txt.use_module = True
    UI.register()
    for im in bpy.data.images:
        if im.filepath and not im.packed_file:
            try:
                im.pack()
            except Exception:
                pass
    out = os.path.join(KIT, "Kit_ChuyMinesitoo.blend")
    bpy.ops.wm.save_as_mainfile(filepath=out, relative_remap=True, compress=True)
    log("guardado", out)
    if "previews" in ARGS:
        previews(scn, town, rig, F)


def render(scene, path, pct=50, cam=None, res=None):
    if cam is not None:
        scene.camera = cam
    if res:
        scene.render.resolution_x, scene.render.resolution_y = res
    scene.render.resolution_percentage = pct
    scene.render.filepath = path
    scene.render.image_settings.file_format = "PNG"
    bpy.ops.render.render(write_still=True, scene=scene.name)
    log("render", os.path.basename(path))


def previews(scn, town, rig, F):
    pv = os.path.join(KIT, "previews")
    os.makedirs(pv, exist_ok=True)
    only = [a.split("=")[1] for a in ARGS if a.startswith("only=")]
    want = lambda k: not only or k in only[0].split(",")
    obj = bpy.data.objects
    if want("cuerpo"):
        render(scn, os.path.join(pv, "cuerpo_frente.png"), 50, obj["Cam_Cuerpo"])
        render(scn, os.path.join(pv, "cuerpo_tres_cuartos.png"), 50, obj["Cam_Tres_Cuartos"])
    if want("caras"):
        for e in UI.EXPRESIONES:
            UI.aplicar(rig, e)
            bpy.context.view_layer.update()
            render(scn, os.path.join(pv, f"cara_{e}.png"), 100, obj["Cam_Cara"], (600, 600))
        UI.aplicar(rig, "Neutral")
    if want("poses"):
        for p in UI.POSES:
            UI.pose(rig, p)
            bpy.context.view_layer.update()
            render(scn, os.path.join(pv, f"pose_{p}.png"), 100, obj["Cam_Tres_Cuartos"], (540, 960))
        UI.pose(rig, "Reposo")
    if want("pueblo") and town is not None:
        UI.aplicar(rig, "Muy feliz")
        UI.pose(rig, "Saludar")
        bpy.context.view_layer.update()
        render(town, os.path.join(pv, "chuy_en_el_pueblo.png"), 50)
        UI.aplicar(rig, "Neutral")
        UI.pose(rig, "Reposo")
    scn.render.resolution_x, scn.render.resolution_y = 1080, 1920
    scn.render.resolution_percentage = 100


try:
    main()
    log("OK")
except Exception:
    log(traceback.format_exc())
LOG.close()
