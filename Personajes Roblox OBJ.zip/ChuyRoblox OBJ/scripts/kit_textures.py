"""Pinta texturas de ropa con el acomodo de la plantilla clásica de camisa/pantalón R6 (585x559).

Cada personaje tiene dos PNG (Camisa y Pantalon). Las zonas transparentes dejan ver el color de piel.
Se pueden repintar en cualquier editor de imágenes respetando las regiones.
"""
import numpy as np
import bpy, os

S = 4                      # factor de resolución sobre la plantilla (585x559)
TW, TH = 585 * S, 559 * S

TORSO = {"U": (231, 8, 128, 64), "F": (231, 74, 128, 128), "R": (165, 74, 64, 128),
         "L": (361, 74, 64, 128), "B": (427, 74, 128, 128), "D": (231, 204, 128, 64)}
RLIMB = {"U": (217, 289, 64, 64), "L": (19, 355, 64, 128), "B": (85, 355, 64, 128),
         "R": (151, 355, 64, 128), "F": (217, 355, 64, 128), "D": (217, 485, 64, 64)}
LLIMB = {"U": (308, 289, 64, 64), "F": (308, 355, 64, 128), "L": (374, 355, 64, 128),
         "B": (440, 355, 64, 128), "R": (506, 355, 64, 128), "D": (308, 485, 64, 64)}
TSIZE = {"F": (0.7, 0.7), "B": (0.7, 0.7), "R": (0.35, 0.7), "L": (0.35, 0.7), "U": (0.7, 0.35), "D": (0.7, 0.35)}
LSIZE = {"F": (0.35, 0.7), "B": (0.35, 0.7), "R": (0.35, 0.7), "L": (0.35, 0.7), "U": (0.35, 0.35), "D": (0.35, 0.35)}
SIDES = ("F", "B", "L", "R")


def rgba(h, a=1.0):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)] + [a], np.float32)


def darker(h, k):
    c = rgba(h)
    c[:3] = np.clip(c[:3] * k, 0, 1)
    return c


# ---------------------------------------------------------------- SDF
def sd_rect(X, Y, x0, y0, x1, y1, r=0.0):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    hx, hy = abs(x1 - x0) / 2 - r, abs(y1 - y0) / 2 - r
    qx, qy = np.abs(X - cx) - hx, np.abs(Y - cy) - hy
    return np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r


def sd_circle(X, Y, cx, cy, r):
    return np.hypot(X - cx, Y - cy) - r


def sd_ellipse(X, Y, cx, cy, rx, ry):
    k = np.hypot((X - cx) / rx, (Y - cy) / ry)
    return (k - 1.0) * min(rx, ry)


def sd_seg(X, Y, ax, ay, bx, by, r):
    px, py = X - ax, Y - ay
    vx, vy = bx - ax, by - ay
    h = np.clip((px * vx + py * vy) / (vx * vx + vy * vy + 1e-12), 0, 1)
    return np.hypot(px - vx * h, py - vy * h) - r


def sd_poly(X, Y, pts):
    pts = np.asarray(pts, np.float32)
    d = np.full(X.shape, 1e9, np.float32)
    inside = np.zeros(X.shape, bool)
    n = len(pts)
    for i in range(n):
        ax, ay = pts[i]
        bx, by = pts[(i + 1) % n]
        d = np.minimum(d, sd_seg(X, Y, ax, ay, bx, by, 0.0))
        cond = ((ay > Y) != (by > Y)) & (X < (bx - ax) * (Y - ay) / (by - ay + 1e-12) + ax)
        inside ^= cond
    return np.where(inside, -d, d)


# ---------------------------------------------------------------- lienzo
class Face:
    def __init__(self, img, rect, size):
        x, y, w, h = [v * S for v in rect]
        self.px = img[y:y + h, x:x + w]
        self.w, self.h = size
        self.ppm = w / size[0]
        xs = (np.arange(w) + 0.5) / self.ppm
        ys = (np.arange(h) + 0.5) / self.ppm
        self.X, self.Y = np.meshgrid(xs, ys)

    def cov(self, sdf):
        return np.clip(0.5 - sdf * self.ppm, 0, 1)

    def paint(self, col, alpha):
        a = (np.broadcast_to(alpha, self.X.shape) * col[3])[..., None]
        dst = self.px
        da = dst[..., 3:4]
        oa = a + da * (1 - a)
        rgb = (col[:3] * a + dst[..., :3] * da * (1 - a)) / np.maximum(oa, 1e-6)
        # donde todo es transparente, conservamos el color (evita orillas oscuras al filtrar)
        rgb = np.where(oa > 1e-6, rgb, dst[..., :3])
        dst[..., :3] = rgb
        dst[..., 3:4] = oa

    def base(self, col):
        """Fija el color 'de fondo' sin opacidad (para que el filtrado no oscurezca orillas)."""
        self.px[..., :3] = col[:3]

    def fill(self, col):
        self.paint(col, 1.0)

    def cut(self, d):
        """Hace transparente (deja ver la piel) dentro de la forma."""
        self.px[..., 3] *= 1.0 - self.cov(d)

    def sdf(self, col, d):
        self.paint(col, self.cov(d))

    def rect(self, col, x0, y0, x1, y1, r=0.0):
        self.sdf(col, sd_rect(self.X, self.Y, x0, y0, x1, y1, r))

    def circle(self, col, cx, cy, r):
        self.sdf(col, sd_circle(self.X, self.Y, cx, cy, r))

    def line(self, col, ax, ay, bx, by, r):
        self.sdf(col, sd_seg(self.X, self.Y, ax, ay, bx, by, r))

    def poly(self, col, pts):
        self.sdf(col, sd_poly(self.X, self.Y, pts))

    def band(self, col, y0, y1):
        self.rect(col, -1, y0, self.w + 1, y1)


class Sheet:
    """Imagen de plantilla completa con acceso por parte del cuerpo."""

    def __init__(self):
        self.img = np.zeros((TH, TW, 4), np.float32)

    def torso(self, k):
        return Face(self.img, TORSO[k], TSIZE[k])

    def rlimb(self, k):
        return Face(self.img, RLIMB[k], LSIZE[k])

    def llimb(self, k):
        return Face(self.img, LLIMB[k], LSIZE[k])

    def limbs(self, k):
        return [self.rlimb(k), self.llimb(k)]

    def pad(self, p=3 * S):
        img = self.img
        for table in (TORSO, RLIMB, LLIMB):
            for x, y, w, h in table.values():
                x, y, w, h = x * S, y * S, w * S, h * S
                y0, y1 = max(y - p, 0), min(y + h + p, TH)
                x0, x1 = max(x - p, 0), min(x + w + p, TW)
                img[y0:y, x:x + w] = img[y:y + 1, x:x + w]
                img[y + h:y1, x:x + w] = img[y + h - 1:y + h, x:x + w]
                img[y0:y1, x0:x] = img[y0:y1, x:x + 1]
                img[y0:y1, x + w:x1] = img[y0:y1, x + w - 1:x + w]

    def save(self, path, name):
        self.pad()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        im = bpy.data.images.new(name, TW, TH, alpha=True)
        im.pixels.foreach_set(np.ascontiguousarray(self.img[::-1]).ravel())
        im.file_format = "PNG"
        tmp = path[:-4] + "_tmp.png"
        im.filepath_raw = tmp
        import time
        for i in range(5):        # Windows a veces bloquea el archivo un instante
            try:
                im.save()
                os.replace(tmp, path)
                break
            except (RuntimeError, OSError):
                time.sleep(1.0)
        bpy.data.images.remove(im)


# ---------------------------------------------------------------- piezas comunes
def all_torso(sh):
    return [sh.torso(k) for k in TORSO]


def sleeves(sh, col, length=0.86, cuff=None, cuff_w=0.035, inner=None):
    """Mangas: cubren el brazo desde el hombro hasta 'length' (fracción de 0.7 m)."""
    end = 0.7 * length
    for k in SIDES:
        for f in sh.limbs(k):
            f.base(col)
            f.band(col, -1, end)
            if inner is not None:          # puño de camisa debajo del saco
                f.band(inner, end - 0.001, end + 0.04)
            if cuff is not None:
                f.band(cuff, end - cuff_w, end)
    for f in sh.limbs("U"):
        f.fill(col)
    if length >= 0.999:
        for f in sh.limbs("D"):
            f.fill(col)
    else:
        for f in sh.limbs("D"):
            f.base(col)


def hem(sh, col, h=0.04):
    for k in SIDES:
        sh.torso(k).band(col, 0.7 - h, 0.71)


def ribs(f, col, y0, y1, step=0.018, a=0.35):
    c = col.copy()
    c[3] = a
    x = 0.0
    while x < f.w:
        f.rect(c, x, y0, x + step * 0.35, y1)
        x += step


def plaid(f, c1, c2, c3, period=0.11):
    """Cuadros de franela."""
    X, Y = f.X, f.Y
    f.fill(c1)
    vb = (np.mod(X, period) < period * 0.42).astype(np.float32)
    hb = (np.mod(Y, period) < period * 0.42).astype(np.float32)
    dark = c2.copy()
    dark[3] = 0.55
    f.paint(dark, vb)
    f.paint(dark, hb)
    thin = (np.abs(np.mod(X, period) - period * 0.72) < 0.004) | (np.abs(np.mod(Y, period) - period * 0.72) < 0.004)
    lt = c3.copy()
    lt[3] = 0.8
    f.paint(lt, thin.astype(np.float32))


# ---------------------------------------------------------------- camisas
def shirt_tee(sh, c, collar=None, sleeve=0.86, cuff=None, hem_c=None, print_fn=None):
    col = rgba(c)
    collar = rgba(collar) if collar else darker(c, 0.75)
    for f in all_torso(sh):
        f.fill(col)
    F = sh.torso("F")
    d = sd_ellipse(F.X, F.Y, 0.35, 0.0, 0.12, 0.085)
    F.sdf(collar, np.abs(d) - 0.014)
    B = sh.torso("B")
    B.sdf(collar, np.abs(sd_ellipse(B.X, B.Y, 0.35, 0.0, 0.12, 0.03)) - 0.012)
    U = sh.torso("U")
    U.sdf(collar, np.abs(sd_ellipse(U.X, U.Y, 0.35, 0.175, 0.13, 0.1)) - 0.012)
    hem(sh, rgba(hem_c) if hem_c else darker(c, 0.85))
    sleeves(sh, col, sleeve, cuff=rgba(cuff) if cuff else darker(c, 0.85))
    if print_fn:
        print_fn(F)


def shirt_suit(sh, suit, inner="#ffffff", tie="#3b4a68", sleeve=0.86, buttons=True):
    s, w, t = rgba(suit), rgba(inner), rgba(tie)
    dk = darker(suit, 0.7)
    for f in all_torso(sh):
        f.fill(s)
    F = sh.torso("F")
    F.poly(w, [(0.24, -0.01), (0.46, -0.01), (0.35, 0.34)])
    # cuello de la camisa
    F.poly(w, [(0.25, -0.01), (0.33, 0.0), (0.3, 0.07)])
    F.poly(w, [(0.45, -0.01), (0.37, 0.0), (0.4, 0.07)])
    # corbata
    F.poly(t, [(0.33, 0.0), (0.37, 0.0), (0.365, 0.045), (0.335, 0.045)])
    F.poly(t, [(0.335, 0.045), (0.365, 0.045), (0.38, 0.27), (0.35, 0.31), (0.32, 0.27)])
    # solapas
    F.line(dk, 0.24, 0.0, 0.335, 0.35, 0.006)
    F.line(dk, 0.46, 0.0, 0.365, 0.35, 0.006)
    F.poly(dk, [(0.24, 0.0), (0.18, 0.0), (0.2, 0.06), (0.17, 0.12), (0.33, 0.36)])
    F.poly(dk, [(0.46, 0.0), (0.52, 0.0), (0.5, 0.06), (0.53, 0.12), (0.37, 0.36)])
    F.poly(s, [(0.245, 0.01), (0.2, 0.01), (0.215, 0.065), (0.19, 0.115), (0.325, 0.33)])
    F.poly(s, [(0.455, 0.01), (0.5, 0.01), (0.485, 0.065), (0.51, 0.115), (0.375, 0.33)])
    F.line(dk, 0.35, 0.35, 0.35, 0.71, 0.004)
    if buttons:
        for y in (0.44, 0.55):
            F.circle(dk, 0.375, y, 0.012)
    F.line(dk, 0.1, 0.48, 0.22, 0.48, 0.005)
    F.line(dk, 0.48, 0.48, 0.6, 0.48, 0.005)
    F.line(dk, 0.48, 0.2, 0.58, 0.2, 0.004)
    sh.torso("B").line(dk, 0.35, 0.3, 0.35, 0.71, 0.004)
    hem(sh, darker(suit, 0.88), 0.02)
    sleeves(sh, s, sleeve, cuff=darker(suit, 0.82), cuff_w=0.02, inner=w)


def shirt_police(sh, body="#2f68b8", yoke="#78aae8", badge="#f2c94c"):
    b, y, g = rgba(body), rgba(yoke), rgba(badge)
    dk = darker(body, 0.65)
    for f in all_torso(sh):
        f.fill(b)
        f.band(y, -1, 0.14) if f.h > 0.4 else None
    sh.torso("U").fill(y)
    F = sh.torso("F")
    F.poly(dk, [(0.27, -0.01), (0.43, -0.01), (0.35, 0.12)])
    F.poly(y, [(0.29, -0.01), (0.41, -0.01), (0.35, 0.09)])
    F.line(dk, 0.35, 0.12, 0.35, 0.62, 0.004)
    for yy in (0.2, 0.3, 0.4, 0.5):
        F.circle(dk, 0.37, yy, 0.009)
    for x0 in (0.09, 0.44):
        F.rect(dk, x0, 0.2, x0 + 0.17, 0.25, 0.01)
        F.rect(darker(body, 0.85), x0 + 0.005, 0.25, x0 + 0.165, 0.36, 0.01)
    star = []
    import math
    for i in range(10):
        r = 0.045 if i % 2 == 0 else 0.02
        a = -math.pi / 2 + i * math.pi / 5
        star.append((0.53 + r * math.cos(a), 0.15 + r * math.sin(a)))
    F.poly(g, star)
    for k in SIDES:
        sh.torso(k).band(rgba("#1d1d1f"), 0.62, 0.7)
    F.rect(rgba("#c9ccd2"), 0.3, 0.625, 0.4, 0.695, 0.008)
    F.rect(rgba("#1d1d1f"), 0.32, 0.64, 0.38, 0.68, 0.004)
    sleeves(sh, y, 0.86, cuff=darker("#78aae8", 0.8))
    for k in SIDES:
        for f in sh.limbs(k):
            f.band(b, 0.33, 0.39)


def shirt_jumpsuit(sh, c="#f08a3a", tag="#ffffff"):
    col = rgba(c)
    dk = darker(c, 0.75)
    for f in all_torso(sh):
        f.fill(col)
    F = sh.torso("F")
    F.poly(dk, [(0.26, -0.01), (0.44, -0.01), (0.35, 0.15)])
    F.poly(col, [(0.28, -0.01), (0.42, -0.01), (0.35, 0.12)])
    F.line(dk, 0.35, 0.15, 0.35, 0.71, 0.005)
    F.rect(rgba(tag), 0.44, 0.2, 0.6, 0.27, 0.008)
    for yy in (0.225, 0.245):
        F.line(rgba("#555555"), 0.46, yy, 0.58, yy, 0.003)
    B = sh.torso("B")
    B.rect(rgba(tag), 0.2, 0.15, 0.5, 0.3, 0.01)
    for i in range(4):
        B.rect(rgba("#333333"), 0.24 + i * 0.065, 0.18, 0.28 + i * 0.065, 0.27, 0.004)
    sleeves(sh, col, 0.84, cuff=dk)


def shirt_cardigan(sh, c, inner="#ffffff", collar=None, buttons="#f4f0e6", sleeve=0.86):
    col, inn = rgba(c), rgba(inner)
    dk = darker(c, 0.8)
    for f in all_torso(sh):
        f.fill(col)
    F = sh.torso("F")
    F.poly(inn, [(0.25, -0.01), (0.45, -0.01), (0.37, 0.4), (0.33, 0.4)])
    F.line(dk, 0.25, -0.01, 0.33, 0.4, 0.007)
    F.line(dk, 0.45, -0.01, 0.37, 0.4, 0.007)
    F.line(dk, 0.35, 0.4, 0.35, 0.71, 0.006)
    for yy in (0.46, 0.54, 0.62):
        F.circle(rgba(buttons), 0.37, yy, 0.013)
    if collar:
        F.sdf(rgba(collar), sd_ellipse(F.X, F.Y, 0.3, 0.03, 0.06, 0.045))
        F.sdf(rgba(collar), sd_ellipse(F.X, F.Y, 0.4, 0.03, 0.06, 0.045))
    for k in SIDES:
        f = sh.torso(k)
        f.band(dk, 0.64, 0.71)
        ribs(f, darker(c, 0.6), 0.64, 0.7)
    sleeves(sh, col, sleeve, cuff=dk, cuff_w=0.05)


def shirt_flannel(sh, c1="#2b5aa6", c2="#13284f", c3="#a9c6f0", inner="#9cc7f2"):
    a, b, l, inn = rgba(c1), rgba(c2), rgba(c3), rgba(inner)
    for f in all_torso(sh):
        plaid(f, a, b, l)
    F = sh.torso("F")
    F.poly(inn, [(0.27, -0.01), (0.43, -0.01), (0.42, 0.71), (0.28, 0.71)])
    F.line(darker(inner, 0.7), 0.27, -0.01, 0.28, 0.71, 0.006)
    F.line(darker(inner, 0.7), 0.43, -0.01, 0.42, 0.71, 0.006)
    for k in SIDES:
        for f in sh.limbs(k):
            f.base(a)
            plaid(f, a, b, l)
    # cortar la manga: dejamos la mano descubierta
    for k in SIDES:
        for f in sh.limbs(k):
            f.px[int(0.7 * 0.86 * f.ppm):, :, 3] = 0
            f.band(darker(c1, 0.6), 0.7 * 0.86 - 0.03, 0.7 * 0.86)
    for f in sh.limbs("U"):
        plaid(f, a, b, l)
    for f in sh.limbs("D"):
        f.base(a)


def shirt_sweater(sh, c, rib=None, sleeve=0.86, stripes=None, heart=None):
    col = rgba(c)
    r = rgba(rib) if rib else darker(c, 0.82)
    for f in all_torso(sh):
        f.fill(col)
        if stripes:
            for i in range(0, 12, 2):
                f.band(rgba(stripes), 0.06 + i * 0.055, 0.06 + i * 0.055 + 0.05)
    F = sh.torso("F")
    F.sdf(r, np.abs(sd_ellipse(F.X, F.Y, 0.35, 0.0, 0.11, 0.07)) - 0.016)
    for k in SIDES:
        f = sh.torso(k)
        f.band(r, 0.63, 0.71)
        ribs(f, darker(c, 0.65), 0.63, 0.7)
    if heart:
        h = rgba(heart)
        F.circle(h, 0.32, 0.3, 0.04)
        F.circle(h, 0.38, 0.3, 0.04)
        F.poly(h, [(0.282, 0.315), (0.418, 0.315), (0.35, 0.4)])
    sleeves(sh, col, sleeve, cuff=r, cuff_w=0.05)
    if stripes:
        for k in SIDES:
            for f in sh.limbs(k):
                for i in range(0, 10, 2):
                    y0 = 0.04 + i * 0.055
                    if y0 + 0.05 < 0.7 * sleeve - 0.05:
                        f.band(rgba(stripes), y0, y0 + 0.05)


def shirt_chef(sh, c="#f7f7f5", btn="#9aa0a8"):
    col = rgba(c)
    dk = darker(c, 0.85)
    for f in all_torso(sh):
        f.fill(col)
    F = sh.torso("F")
    F.band(dk, 0.0, 0.05)
    F.line(darker(c, 0.75), 0.18, 0.05, 0.48, 0.71, 0.004)
    for yy in (0.15, 0.27, 0.39, 0.51):
        F.circle(rgba(btn), 0.24, yy, 0.014)
        F.circle(rgba(btn), 0.46, yy, 0.014)
    F.line(dk, 0.48, 0.2, 0.6, 0.2, 0.004)
    sleeves(sh, col, 0.86, cuff=dk, cuff_w=0.05)


def shirt_nurse(sh, c="#e4eef9", cross="#e0393e"):
    col = rgba(c)
    dk = darker(c, 0.8)
    for f in all_torso(sh):
        f.fill(col)
    F = sh.torso("F")
    F.poly(dk, [(0.27, -0.01), (0.43, -0.01), (0.35, 0.14)])
    F.cut(sd_poly(F.X, F.Y, [(0.29, -0.01), (0.41, -0.01), (0.35, 0.11)]))
    F.line(dk, 0.35, 0.14, 0.35, 0.71, 0.004)
    F.rect(rgba(cross), 0.495, 0.14, 0.525, 0.24)
    F.rect(rgba(cross), 0.46, 0.175, 0.56, 0.205)
    F.rect(dk, 0.1, 0.45, 0.25, 0.47)
    hem(sh, dk, 0.02)
    sleeves(sh, col, 0.42, cuff=rgba(cross), cuff_w=0.02)


def shirt_mail(sh, c="#8ec1ea", strap="#7a4a2a"):
    shirt_tee(sh, c, sleeve=0.42)
    F = sh.torso("F")
    st = rgba(strap)
    F.line(st, 0.66, -0.02, 0.06, 0.72, 0.03)
    for x0 in (0.1, 0.45):
        F.rect(darker(c, 0.8), x0, 0.2, x0 + 0.15, 0.24, 0.006)
    B = sh.torso("B")
    B.line(st, 0.04, -0.02, 0.64, 0.72, 0.03)
    sh.torso("U").line(st, 0.0, 0.0, 0.25, 0.35, 0.03)


def apron_front(F, c="#e8873a", y0=0.12):
    a = rgba(c)
    F.poly(a, [(0.16, y0), (0.54, y0), (0.56, 0.71), (0.14, 0.71)])
    F.line(a, 0.18, y0, 0.08, -0.02, 0.018)
    F.line(a, 0.52, y0, 0.62, -0.02, 0.018)
    F.rect(darker(c, 0.8), 0.27, 0.3, 0.43, 0.42, 0.01)
    F.rect(a, 0.275, 0.305, 0.425, 0.415, 0.008)
    F.line(darker(c, 0.75), 0.35, 0.3, 0.35, 0.42, 0.003)


# ---------------------------------------------------------------- pantalones
def pants(sh, c, shoes="#2a2a2a", length=1.0, belt=None, sock=None, apron=None, seams=False, sole=None):
    col = rgba(c)
    sc = rgba(shoes)
    for k in SIDES:
        for f in sh.limbs(k):
            f.base(col)
            f.band(col, -1, 0.7 * length)
            if length < 1:
                f.band(darker(c, 0.82), 0.7 * length - 0.03, 0.7 * length)
            if sock:
                f.band(rgba(sock), 0.5, 0.6)
            f.band(sc, 0.6, 0.71)
            f.band(rgba(sole) if sole else darker(shoes, 0.6), 0.675, 0.71)
            if seams and k in ("L", "R"):
                f.line(darker(c, 0.75), 0.175, 0.0, 0.175, 0.7 * length - 0.03, 0.003)
    for f in sh.limbs("U"):
        f.fill(col)
    for f in sh.limbs("D"):
        f.fill(darker(shoes, 0.6))
    for f in sh.limbs("F"):
        f.band(sc, 0.6, 0.71)
        f.rect(darker(shoes, 1.25) if shoes != "#ffffff" else rgba("#e6e6e6"), 0.04, 0.6, 0.31, 0.64, 0.01)
    if apron:
        for f in sh.limbs("F"):
            f.band(rgba(apron), -1, 0.32)
    for k in TORSO:
        f = sh.torso(k)
        f.base(col)
        if k in SIDES:
            f.band(col, 0.6, 0.71)
            if belt:
                f.band(rgba(belt), 0.6, 0.65)


def skirt_legs(sh, c, skin, shoes="#2a2a2a", length=0.6):
    """Falda pintada en las piernas (útil si no se usa la falda 3D)."""
    col = rgba(c)
    for k in SIDES:
        for f in sh.limbs(k):
            f.base(col)
            f.band(col, -1, 0.7 * length)
            f.band(rgba(shoes), 0.6, 0.71)
            f.band(darker(shoes, 0.6), 0.675, 0.71)
    for f in sh.limbs("U"):
        f.fill(col)
    for f in sh.limbs("D"):
        f.fill(darker(shoes, 0.6))
